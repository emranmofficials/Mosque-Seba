package com.mosqueseba.app.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import com.mosqueseba.app.data.local.DatabaseInitializer
import com.mosqueseba.app.data.local.MosqueDatabase
import com.mosqueseba.app.data.local.SessionManager
import com.mosqueseba.app.data.local.entity.*
import com.mosqueseba.app.data.model.UserRole
import com.mosqueseba.app.data.repository.MosqueRepository
import com.mosqueseba.app.data.updater.AppUpdateInfo
import com.mosqueseba.app.data.updater.AppUpdateManager
import com.mosqueseba.app.ui.components.toBengaliDigits
import com.mosqueseba.app.data.remote.supabase.SupabaseAuthClient
import com.mosqueseba.app.data.remote.supabase.SupabaseConfig
import com.mosqueseba.app.data.remote.supabase.SupabaseHttpClient
import com.mosqueseba.app.data.remote.supabase.SupabaseRealtimeClient
import com.mosqueseba.app.data.remote.supabase.SupabaseSyncManager
import com.mosqueseba.app.data.remote.supabase.SyncResult
import com.mosqueseba.app.util.MosquePushNotificationHelper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import com.mosqueseba.app.data.model.IslamicEvent
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

private const val TAG = "MosqueViewModel"

sealed interface AiNoticeUiState {
    data object Idle : AiNoticeUiState
    data object Loading : AiNoticeUiState
    data class Success(val title: String, val content: String) : AiNoticeUiState
    data class Error(val message: String) : AiNoticeUiState
}

sealed interface AiSummaryUiState {
    data object Idle : AiSummaryUiState
    data object Loading : AiSummaryUiState
    data class Streaming(val text: String) : AiSummaryUiState
    data class Success(val text: String) : AiSummaryUiState
    data class Error(val message: String) : AiSummaryUiState
}

sealed interface AiEventGuidanceUiState {
    data object Idle : AiEventGuidanceUiState
    data object Loading : AiEventGuidanceUiState
    data class Success(
        val eventId: String,
        val fullGuidanceText: String
    ) : AiEventGuidanceUiState
    data class Error(val message: String) : AiEventGuidanceUiState
}

sealed interface AiDawatnamaUiState {
    data object Idle : AiDawatnamaUiState
    data object Loading : AiDawatnamaUiState
    data class Success(val description: String) : AiDawatnamaUiState
    data class Error(val message: String) : AiDawatnamaUiState
}

/** Firebase AI errors -> actionable Bengali guidance for mosque staff. */
internal fun friendlyAiError(e: Exception): String {
    val raw = "${e.localizedMessage.orEmpty()} ${e.javaClass.simpleName}".lowercase(Locale.US)
    return when {
        "403" in raw || "appcheck" in raw || "app check" in raw || "attestation" in raw ||
                "unauthenticated" in raw || "permission" in raw ->
            "এআই পরিষেবায় প্রবেশ বাতিল হয়েছে (App Check)। Firebase Console-এ App Check ও reCAPTCHA সঠিকভাবে সেট আছে কি না যাচাই করুন।"
        "429" in raw || "quota" in raw || "rate" in raw || "resource_exhausted" in raw ->
            "এআই ব্যবহারের দৈনিক সীমা শেষ হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।"
        "404" in raw || "notfound" in raw || "not found" in raw ||
                ("api" in raw && ("disabled" in raw || "not enabled" in raw)) ->
            "Firebase প্রকল্পে Gemini / AI Logic API চালু নেই। Firebase Console → AI Logic-এ API enable করুন।"
        "401" in raw || "api key" in raw || "invalid key" in raw || "unauthorized" in raw ->
            "Firebase কনফিগারেশন বৈধ নয়। app/google-services.json-এ আসল কনফিগ আছে কি না যাচাই করুন।"
        "network" in raw || "unresolved" in raw || "failed to connect" in raw ||
                "timeout" in raw || "offline" in raw ->
            "ইন্টারনেট সংযোগ পাওয়া যায়নি। সংযোগ ঠিক করে আবার চেষ্টা করুন।"
        else -> e.localizedMessage?.takeIf { it.isNotBlank() }
            ?: "এআই অনুরোধ ব্যর্থ হয়েছে। আবার চেষ্টা করুন।"
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class MosqueViewModel(application: Application) : AndroidViewModel(application) {

    // These MUST be initialized before the init block: startRealtimeSyncLoop()
    // launches a coroutine that reads them immediately (property initializers
    // run in declaration order, so declaring them after init caused an NPE on
    // every cold start).
    val sessionManager = SessionManager(application)
    private val syncInFlight = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var lastRealtimeSyncMs = 0L
    // If a Realtime event arrives while a sync is already running (or inside the
    // short self-echo cooldown), remember it and replay it afterwards instead of
    // dropping it. This is what caused "live update never appears, works after
    // restart": the member's chanda event was silently discarded while a sync
    // was in flight, and only the cold-start sync brought the data in.
    private val realtimeSyncPending = java.util.concurrent.atomic.AtomicBoolean(false)

    private val repository: MosqueRepository

    private val _availableUpdate = MutableStateFlow<AppUpdateInfo?>(null)
    val availableUpdate: StateFlow<AppUpdateInfo?> = _availableUpdate.asStateFlow()

    init {
        val db = MosqueDatabase.getDatabase(application, viewModelScope)
        repository = MosqueRepository(db)
        MosquePushNotificationHelper.initChannels(application)
        checkForAppUpdates(forceManual = false)
        startRealtimeSyncLoop()
    }

    /**
     * When the cloud sync pulls in a NEW chanda receipt belonging to the signed-in
     * member (recorded by the treasurer on another device), post a status-bar
     * notification. This is the remote counterpart of recordChandaPayment()'s
     * local notification — without it a member only saw the receipt after a
     * manual app restart.
     */
    private fun observeRemoteChandaReceipts(db: MosqueDatabase) {
        viewModelScope.launch(Dispatchers.IO) {
            val seen = java.util.Collections.newSetFromMap(
                java.util.concurrent.ConcurrentHashMap<String, Boolean>()
            )
            var primed = false
            db.chandaDao().getAllPayments().collect { payments ->
                val savedId = sessionManager.getSavedMemberId()
                if (!primed) {
                    // Seed with existing receipts so we don't notify for old data
                    // on app launch / first emission.
                    payments.forEach { seen.add(it.id) }
                    primed = true
                } else if (!savedId.isNullOrBlank()) {
                    payments.filter { it.memberId == savedId && it.id !in seen }
                        .forEach { receipt ->
                            seen.add(receipt.id)
                            if (sessionManager.isNotificationsEnabled()) {
                                MosquePushNotificationHelper.postChandaReceiptNotification(
                                    getApplication(), receipt
                                )
                            }
                        }
                }
            }
        }
    }

    fun checkForAppUpdates(forceManual: Boolean = false, onResult: ((AppUpdateInfo?) -> Unit)? = null) {
        viewModelScope.launch {
            val update = AppUpdateManager.checkLatestRelease(getApplication(), forceCheck = forceManual)
            if (update != null && update.isUpdateAvailable) {
                val isDismissed = !forceManual && AppUpdateManager.isVersionDismissed(getApplication(), update.latestVersionName)
                if (!isDismissed) {
                    _availableUpdate.value = update
                }
            } else if (forceManual) {
                _availableUpdate.value = update
            }
            onResult?.invoke(update)
        }
    }

    fun dismissUpdateDialog(versionName: String) {
        AppUpdateManager.dismissVersion(getApplication(), versionName)
        _availableUpdate.value = null
    }

    // Role & Persistent Authentication
    private val _currentUserRole = MutableStateFlow(
        if (sessionManager.isLoggedIn()) sessionManager.getSavedRole() else UserRole.PRESIDENT
    )
    val currentUserRole: StateFlow<UserRole> = _currentUserRole.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(sessionManager.isLoggedIn())
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    fun setUserRole(role: UserRole) {
        _currentUserRole.value = role
    }

    private val _notificationsEnabled = MutableStateFlow(sessionManager.isNotificationsEnabled())
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

    private val _showHijriBanner = MutableStateFlow(sessionManager.isHijriBannerVisible())
    val showHijriBanner: StateFlow<Boolean> = _showHijriBanner.asStateFlow()

    private val _hijriDayOffset = MutableStateFlow(sessionManager.getHijriDayOffset())
    val hijriDayOffset: StateFlow<Int> = _hijriDayOffset.asStateFlow()

    private val _rememberMeEnabled = MutableStateFlow(sessionManager.isRememberMeEnabled())
    val rememberMeEnabled: StateFlow<Boolean> = _rememberMeEnabled.asStateFlow()

    private val _darkModeEnabled = MutableStateFlow(sessionManager.isDarkModeEnabled())
    val darkModeEnabled: StateFlow<Boolean> = _darkModeEnabled.asStateFlow()

    private val _darkModeFollowSystem = MutableStateFlow(sessionManager.hasUserSetDarkMode().not())
    val darkModeFollowSystem: StateFlow<Boolean> = _darkModeFollowSystem.asStateFlow()

    private val _readNotificationIds = MutableStateFlow(sessionManager.getReadNotificationIds())
    val readNotificationIds: StateFlow<Set<String>> = _readNotificationIds.asStateFlow()

    private fun todayDateIso(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date())

    private val _khademCheckedTasks = MutableStateFlow(
        sessionManager.getKhademCheckedTasksForDate(todayDateIso())
    )
    val khademCheckedTasks: StateFlow<Set<String>> = _khademCheckedTasks.asStateFlow()

    fun toggleKhademTask(taskId: String) {
        _khademCheckedTasks.value = sessionManager.toggleKhademTaskForDate(todayDateIso(), taskId)
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        sessionManager.setNotificationsEnabled(enabled)
        _notificationsEnabled.value = enabled
    }

    // Supabase Cloud Backend & Realtime Sync Engine (fields declared above init)

    /** Keeps the Auth JWT fresh so REST/Realtime RLS never sees an expired token. */
    private suspend fun ensureFreshAuthToken() {
        val refreshToken = sessionManager.getRefreshToken() ?: return
        if (!sessionManager.isAuthTokenExpired()) return
        val refreshed = SupabaseAuthClient(getApplication()).refresh(refreshToken)
        if (refreshed.isSuccess) {
            val session = refreshed.getOrNull() ?: return
            sessionManager.saveAuthSession(
                session.accessToken, session.refreshToken, session.expiresIn,
                session.uid, session.email
            )
        } else {
            sessionManager.clearAuthSession()
            SupabaseRealtimeClient.stop()
        }
    }

    /**
     * Runs a sync promptly after a local write or a Realtime event.
     * Bursts/self-echoes are COALESCED (replayed once afterwards), never dropped.
     */
    fun triggerImmediateCloudSync(force: Boolean = false) {
        // An event arriving during a cooldown/lock sets this flag; the running
        // sync replays one more pass when it finishes so no change is lost.
        if (!force) realtimeSyncPending.set(true)
        viewModelScope.launch(Dispatchers.IO) {
            ensureFreshAuthToken()
            val tooSoon = !force && System.currentTimeMillis() - lastRealtimeSyncMs < 3_000
            if (tooSoon) return@launch // flag guarantees a replay after the current sync
            if (!syncInFlight.compareAndSet(false, true)) return@launch
            try {
                do {
                    realtimeSyncPending.set(false)
                    val db = MosqueDatabase.getDatabase(getApplication(), viewModelScope)
                    SupabaseSyncManager.performSync(getApplication(), db)
                } while (realtimeSyncPending.get())
            } catch (e: Exception) {
                Log.w(TAG, "Immediate cloud sync skipped", e)
            } finally {
                // Cooldown starts when the sync finishes, so our own upserts
                // echoing back from Realtime cannot start an endless loop.
                lastRealtimeSyncMs = System.currentTimeMillis()
                syncInFlight.set(false)
            }
        }
    }

    /** (Re)opens the Realtime channel with the current Auth JWT. Safe to call repeatedly. */
    private fun restartRealtime() {
        SupabaseRealtimeClient.start(getApplication()) { table ->
            // A sync that is already running reads the LATEST cloud state, so any
            // event arriving mid-sync is either the echo of our own upsert or a
            // change that sync is about to pull. Ignoring it kills echo-driven
            // sync loops; genuine later events still open a fresh sync.
            if (syncInFlight.get()) return@start
            // chanda_payments / transactions events carry money + receipt changes;
            // bypass the cooldown so a member sees the update immediately.
            val isMoneyEvent = table == "chanda_payments" || table == "transactions"
            triggerImmediateCloudSync(force = isMoneyEvent)
        }
    }

    private fun startRealtimeSyncLoop() {
        viewModelScope.launch(Dispatchers.IO) {
            ensureFreshAuthToken()
            val db = MosqueDatabase.getDatabase(getApplication(), viewModelScope)
            // 1. Initial sync immediately on launch
            try {
                SupabaseSyncManager.performSync(getApplication(), db)
            } catch (e: Exception) {
                Log.w(TAG, "Initial Supabase sync skipped", e)
            }
            lastRealtimeSyncMs = System.currentTimeMillis()

            // 1b. Start the remote-receipt observer ONLY after the initial sync has
            // populated Room. If it ran from init(), the first (empty) Flow emission
            // would prime nothing and every historical receipt pulled by the cold
            // sync would fire a spurious status-bar notification.
            observeRemoteChandaReceipts(db)

            // 2. True realtime: a WSS channel listens for postgres_changes and
            //    triggers an immediate sync whenever any synced table changes.
            restartRealtime()

            // 3. Safety net: poll only while disconnected, plus a periodic
            //    refresh to recover events missed during a network gap.
            var lastFallbackSyncMs = System.currentTimeMillis()
            while (isActive) {
                delay(15_000)
                SupabaseRealtimeClient.refreshFilter(getApplication())
                val now = System.currentTimeMillis()
                if (!SupabaseRealtimeClient.isConnected() || now - lastFallbackSyncMs >= 300_000) {
                    try {
                        SupabaseSyncManager.performSync(getApplication(), db)
                        lastFallbackSyncMs = System.currentTimeMillis()
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    override fun onCleared() {
        SupabaseRealtimeClient.stop()
        super.onCleared()
    }

    fun performCloudSync(onResult: (SyncResult) -> Unit) {
        viewModelScope.launch {
            ensureFreshAuthToken()
            val db = MosqueDatabase.getDatabase(getApplication(), viewModelScope)
            val result = SupabaseSyncManager.performSync(getApplication(), db)
            onResult(result)
        }
    }

    suspend fun testCloudConnection(): Result<Boolean> {
        val client = SupabaseHttpClient(getApplication())
        return client.testConnection()
    }

    fun saveSupabaseCredentials(url: String, key: String) {
        SupabaseConfig.saveCredentials(getApplication(), url, key)
    }

    fun getSupabaseCredentials(): Pair<String, String> {
        return SupabaseConfig.getCredentials(getApplication())
    }

    fun isSupabaseConfigured(): Boolean {
        return SupabaseConfig.isConfigured(getApplication())
    }

    fun getLastCloudSyncTime(): String? {
        return SupabaseConfig.getLastSyncTime(getApplication())
    }

    fun setShowHijriBanner(visible: Boolean) {
        sessionManager.setHijriBannerVisible(visible)
        _showHijriBanner.value = visible
    }

    fun setHijriDayOffset(offset: Int) {
        sessionManager.setHijriDayOffset(offset)
        _hijriDayOffset.value = offset
    }

    fun setRememberMeEnabled(enabled: Boolean) {
        sessionManager.setRememberMeEnabled(enabled)
        _rememberMeEnabled.value = enabled
    }

    fun setDarkModeEnabled(enabled: Boolean) {
        sessionManager.setDarkModeEnabled(enabled)
        _darkModeEnabled.value = enabled
        _darkModeFollowSystem.value = false
    }

    fun setDarkModeFollowSystem() {
        sessionManager.clearDarkModePreference()
        _darkModeFollowSystem.value = true
    }

    fun markNotificationAsRead(notificationId: String) {
        sessionManager.markNotificationRead(notificationId)
        _readNotificationIds.value = sessionManager.getReadNotificationIds()
    }

    fun markAllNotificationsAsRead(notificationIds: Collection<String>) {
        sessionManager.markAllNotificationsRead(notificationIds)
        _readNotificationIds.value = sessionManager.getReadNotificationIds()
    }

    suspend fun changeCurrentUserPassword(
        currentPassword: String,
        newPassword: String
    ): Pair<Boolean, String> {
        val trimmedCurrent = currentPassword.trim()
        val trimmedNew = newPassword.trim()
        if (trimmedNew.length < 6) {
            return Pair(false, "নতুন পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।")
        }

        val role = _currentUserRole.value
        val activeMosque = mosque.value
        val committeeId = activeMosque?.committeeId ?: sessionManager.getSavedCommitteeId()
        val mosqueId = activeMosque?.id ?: _activeMosqueId.value
        val savedMemberId = sessionManager.getSavedMemberId().orEmpty()
        val member = allMembers.value.firstOrNull { it.id == savedMemberId }
            ?: allMembers.value.firstOrNull { it.roleCode.equals(role.code, ignoreCase = true) }
        val resolvedMemberId = member?.id ?: savedMemberId
        val email = member?.email?.trim()?.lowercase().orEmpty()
        val mobile = member?.mobile?.ifBlank { sessionManager.getSavedMobile() } ?: sessionManager.getSavedMobile()
        val isPresident = role == UserRole.PRESIDENT
        // The exact email this Auth account was created with is stored at login.
        // Fall back to the synthetic/member email only when that is unavailable.
        val authEmail = sessionManager.getAuthEmail()?.takeIf { it.isNotBlank() }
            ?: (if (isPresident) email else SupabaseAuthClient.syntheticEmail(resolvedMemberId))

        // Verify the OLD password against Supabase Auth itself — no local
        // SHA-256 / demo fallback is trusted any more.
        val auth = SupabaseAuthClient(getApplication())
        val session = auth.signIn(authEmail, trimmedCurrent).getOrElse {
            return Pair(false, "বর্তমান পাসওয়ার্ড সঠিক নয়।")
        }
        val updated = auth.updatePassword(session.accessToken, trimmedNew)
        if (updated.isFailure) {
            return Pair(false, updated.exceptionOrNull()?.message ?: "পাসওয়ার্ড পরিবর্তন ব্যর্থ।")
        }
        // Persist the freshly issued session (new access + rotated refresh token)
        // so REST/Realtime keep working and a later refresh never fails.
        sessionManager.saveAuthSession(
            session.accessToken, session.refreshToken, session.expiresIn,
            session.uid, session.email.ifBlank { authEmail }
        )

        // Keep local UX credentials and the cloud profile hash in step.
        if (isPresident) {
            sessionManager.saveRegisteredPresidentEmailCredential(email, committeeId, mosqueId, trimmedNew)
            SupabaseSyncManager.syncPresidentCredential(
                context = getApplication(),
                mosqueId = mosqueId,
                memberId = resolvedMemberId,
                email = email,
                mobile = mobile,
                nameBn = member?.nameBn ?: sessionManager.getSavedMemberName(),
                plainPass = trimmedNew,
                authUserId = sessionManager.getAuthUserId() ?: session.uid
            )
        } else {
            val cleanMobile = mobile.replace("-", "").replace(" ", "").trim()
            sessionManager.saveRegisteredCredential(cleanMobile, committeeId, mosqueId, trimmedNew)
            SupabaseSyncManager.syncMemberCredential(
                context = getApplication(),
                mosqueId = mosqueId,
                memberId = resolvedMemberId,
                authUserId = sessionManager.getAuthUserId() ?: session.uid,
                email = authEmail,
                mobile = mobile,
                nameBn = member?.nameBn ?: sessionManager.getSavedMemberName(),
                plainPass = trimmedNew
            )
        }
        return Pair(true, "পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে।")
    }

    private val _activeMosqueId = MutableStateFlow(sessionManager.getActiveMosqueId())

    suspend fun loginPresidentWithEmail(
        committeeId: String,
        email: String,
        pass: String,
        rememberMe: Boolean = true
    ): Pair<Boolean, String?> {
        val cleanEmail = email.trim().lowercase()
        val trimmedCommitteeId = committeeId.trim()
        if (cleanEmail.isBlank()) return Pair(false, "ইমেইল লিখুন।")
        if (trimmedCommitteeId.isBlank()) return Pair(false, "কমিটি আইডি লিখুন।")

        // 1) Supabase Auth is the only password authority now.
        val auth = SupabaseAuthClient(getApplication())
        val session = auth.signIn(cleanEmail, pass).getOrElse { e ->
            return Pair(false, e.message ?: "লগইন ব্যর্থ।")
        }
        sessionManager.saveAuthSession(
            session.accessToken, session.refreshToken, session.expiresIn,
            session.uid, session.email.ifBlank { cleanEmail }
        )

        // 2) Verify FIRST (before any local DB write) that this Auth account's
        //    profile belongs to the mosque matching the entered committee ID.
        //    RLS on profiles already limits rows to auth.uid(), so this only
        //    returns the signed-in user's own profile.
        val client = SupabaseHttpClient(getApplication())
        val profileRes = client.get("profiles", "auth_user_id=eq.${session.uid}&limit=1")
        if (profileRes.isFailure || (profileRes.getOrNull()?.length() ?: 0) == 0) {
            sessionManager.clearAuthSession()
            return Pair(false, "এই অ্যাকাউন্টটি কোনো মসজিদের সাথে যুক্ত নয়।")
        }
        val ownProfile = profileRes.getOrNull()!!.getJSONObject(0)
        val profileMosqueId = ownProfile.optString("mosque_id")
        val memberId = ownProfile.optString("member_id")
        if (profileMosqueId.isBlank() || memberId.isBlank()) {
            sessionManager.clearAuthSession()
            return Pair(false, "সভাপতি প্রোফাইল পাওয়া যায়নি।")
        }
        val mosqueRes = client.get("mosques", "id=eq.$profileMosqueId&select=committee_id&limit=1")
        val actualCommitteeId = if (mosqueRes.isSuccess && (mosqueRes.getOrNull()?.length() ?: 0) > 0)
            mosqueRes.getOrNull()!!.getJSONObject(0).optString("committee_id") else ""
        if (actualCommitteeId != trimmedCommitteeId) {
            sessionManager.clearAuthSession()
            return Pair(false, "এই অ্যাকাউন্টটি ওই মসজিদের সাথে যুক্ত নয়।")
        }

        // 3) Verification passed — now safe to restore the mosque and its members.
        //    (If this device is switching mosques, local tenant data is cleared.)
        val db = MosqueDatabase.getDatabase(getApplication(), viewModelScope)
        val matchedMosque = SupabaseSyncManager.fetchAndRestoreMosqueByCommitteeId(
            getApplication(), db, trimmedCommitteeId
        ) ?: repository.getMosqueByCommitteeId(trimmedCommitteeId)
        if (matchedMosque == null) {
            sessionManager.clearAuthSession()
            return Pair(false, "প্রদত্ত কমিটি আইডি খুঁজে পাওয়া যায়নি।")
        }
        val member = db.memberDao().getMemberById(memberId) ?: repository.getMemberByEmail(cleanEmail)
        if (member == null) {
            sessionManager.clearAuthSession()
            return Pair(false, "সভাপতি প্রোফাইল পাওয়া যায়নি।")
        }
        val role = UserRole.fromCode(member.roleCode)
        if (role != UserRole.PRESIDENT) {
            sessionManager.clearAuthSession()
            return Pair(false, "শুধুমাত্র সভাপতি ইমেইল ও পাসওয়ার্ড দিয়ে লগইন করতে পারবেন।")
        }

        _activeMosqueId.value = matchedMosque.id
        _currentUserRole.value = role
        _isLoggedIn.value = true
        sessionManager.saveSession(
            role = role,
            memberId = member.id,
            memberName = member.nameBn,
            committeeId = matchedMosque.committeeId,
            mobile = member.mobile,
            rememberMe = rememberMe,
            mosqueId = matchedMosque.id
        )
        restartRealtime()
        return Pair(true, null)
    }

    suspend fun loginMemberWithMobile(
        committeeId: String,
        mobile: String,
        pass: String,
        rememberMe: Boolean = true
    ): Pair<Boolean, String?> {
        val cleanMobile = mobile.replace("-", "").replace(" ", "").trim()
        val trimmedCommitteeId = committeeId.trim()
        if (cleanMobile.isBlank()) return Pair(false, "মোবাইল নম্বর লিখুন।")
        if (trimmedCommitteeId.isBlank()) return Pair(false, "কমিটি আইডি লিখুন।")

        val client = SupabaseHttpClient(getApplication())

        // 1) Narrow anonymous RPCs resolve mosque + member before we have a JWT.
        val mosqueRes = client.callRpc(
            "seba_lookup_committee",
            JSONObject().put("p_committee_id", trimmedCommitteeId),
            useAnon = true
        )
        val mosqueJson = if (mosqueRes.isSuccess) {
            try {
                JSONObject(mosqueRes.getOrNull() ?: "null").takeIf { it.has("id") }
            } catch (_: Exception) { null }
        } else null
        val mosqueId = mosqueJson?.optString("id").orEmpty()
        if (mosqueId.isBlank()) return Pair(false, "প্রদত্ত কমিটি আইডি খুঁজে পাওয়া যায়নি।")

        val memberRes = client.callRpc(
            "seba_lookup_member_by_mobile",
            JSONObject().apply {
                put("p_mosque_id", mosqueId)
                put("p_mobile", cleanMobile)
            },
            useAnon = true
        )
        val memberJson = if (memberRes.isSuccess) {
            try {
                JSONObject(memberRes.getOrNull() ?: "null").takeIf { it.has("id") }
            } catch (_: Exception) { null }
        } else null
        val memberId = memberJson?.optString("id").orEmpty()
        if (memberId.isBlank()) {
            return Pair(false, "এই মোবাইল নম্বরে কোনো নিবন্ধিত সদস্য পাওয়া যায়নি।")
        }
        if (UserRole.fromCode(memberJson!!.optString("role_code")) == UserRole.PRESIDENT) {
            return Pair(false, "সভাপতি মোবাইল দিয়ে নয়, 'সভাপতি লগইন' ট্যাব থেকে ইমেইল ও পাসওয়ার্ড দিয়ে লগইন করুন।")
        }

        // 2) Real Auth login with the deterministic synthetic email.
        val authEmail = SupabaseAuthClient.syntheticEmail(memberId)
        val auth = SupabaseAuthClient(getApplication())
        val session = auth.signIn(authEmail, pass.trim()).getOrElse {
            return Pair(false, "পাসওয়ার্ড সঠিক নয়। আপনার নির্ধারিত পাসওয়ার্ড বা মোবাইল নম্বরের শেষ ৬টি সংখ্যা দিন।")
        }
        sessionManager.saveAuthSession(
            session.accessToken, session.refreshToken, session.expiresIn,
            session.uid, session.email.ifBlank { authEmail }
        )

        // 3) Profile tenant check, then restore this mosque's data.
        val profileRes = client.get("profiles", "auth_user_id=eq.${session.uid}&mosque_id=eq.$mosqueId&limit=1")
        if (profileRes.isFailure || (profileRes.getOrNull()?.length() ?: 0) == 0) {
            sessionManager.clearAuthSession()
            return Pair(false, "এই অ্যাকাউন্টটি ওই মসজিদের সাথে যুক্ত নয়।")
        }

        val db = MosqueDatabase.getDatabase(getApplication(), viewModelScope)
        val restored = SupabaseSyncManager.fetchAndRestoreMosqueByCommitteeId(
            getApplication(), db, trimmedCommitteeId
        )
        if (restored == null) {
            sessionManager.clearAuthSession()
            return Pair(false, "মসজিদের তথ্য ক্লাউড থেকে আনা যায়নি।")
        }
        val member = db.memberDao().getMemberById(memberId)
        val role = if (member != null) UserRole.fromCode(member.roleCode)
                   else UserRole.fromCode(memberJson.optString("role_code"))

        _activeMosqueId.value = mosqueId
        _currentUserRole.value = role
        _isLoggedIn.value = true
        sessionManager.saveSession(
            role = role,
            memberId = memberId,
            memberName = member?.nameBn ?: memberJson.optString("name_bn"),
            committeeId = trimmedCommitteeId,
            mobile = member?.mobile ?: cleanMobile,
            rememberMe = rememberMe,
            mosqueId = mosqueId
        )
        restartRealtime()
        return Pair(true, null)
    }

    suspend fun loginWithCredentials(
        committeeId: String,
        mobile: String,
        pass: String,
        rememberMe: Boolean = true
    ): Pair<Boolean, String?> = loginMemberWithMobile(committeeId, mobile, pass, rememberMe)

    fun quickLoginAsRole(role: UserRole, rememberMe: Boolean = true) {
        _currentUserRole.value = role
        _isLoggedIn.value = true
        val matchedMember = allMembers.value.firstOrNull { it.roleCode.equals(role.code, ignoreCase = true) }
        val name = matchedMember?.nameBn ?: role.titleBn
        val mobile = matchedMember?.mobile ?: ""
        val memberId = matchedMember?.id ?: "mem-${role.code}"
        val activeMosque = mosque.value
        sessionManager.saveSession(
            role = role,
            memberId = memberId,
            memberName = name,
            committeeId = activeMosque?.committeeId ?: "",
            mobile = mobile,
            rememberMe = rememberMe,
            mosqueId = activeMosque?.id ?: _activeMosqueId.value
        )
    }

    suspend fun registerNewMosqueAndPresident(
        presidentNameBn: String,
        presidentNameEn: String,
        presidentMobile: String,
        presidentEmail: String,
        presidentNid: String,
        password: String,
        presidentMonthlyChanda: Double = 0.0,
        willingToProvideStaffMeals: Boolean = false,
        presidentPhotoUri: String? = null,
        mosqueNameBn: String,
        mosqueNameEn: String,
        address: String,
        establishedYear: Int,
        startYear: Int,
        endYear: Int,
        district: String = "",
        upazila: String = "",
        waqfRegNo: String = "",
        capacity: Int? = null,
        bankAccountInfo: String = "",
        mosqueLogoUri: String? = null
    ): Result<String> {
        val committeeId = "MC-REG-${System.currentTimeMillis().toString().takeLast(4)}"
        val mosqueId = "mosque-${UUID.randomUUID().toString().take(8)}"
        val presidentId = "mem-${UUID.randomUUID().toString().take(8)}"

        // A real Supabase Auth user is created first. Without it registration
        // fails — no more local-only demo credentials.
        val auth = SupabaseAuthClient(getApplication())
        val cleanAuthEmail = presidentEmail.trim().lowercase()
        val authSession = auth.signUp(cleanAuthEmail, password).getOrElse { e ->
            return Result.failure(Exception(e.message ?: "অ্যাকাউন্ট তৈরি করা যায়নি।"))
        }
        sessionManager.saveAuthSession(
            authSession.accessToken, authSession.refreshToken, authSession.expiresIn,
            authSession.uid, authSession.email.ifBlank { cleanAuthEmail }
        )

        val mosqueEntity = MosqueEntity(
            id = mosqueId,
            committeeId = committeeId,
            nameBn = mosqueNameBn,
            nameEn = mosqueNameEn.ifBlank { mosqueNameBn },
            address = address,
            establishedYear = establishedYear,
            committeeStartYear = startYear,
            committeeEndYear = endYear,
            status = "active",
            district = district.trim(),
            upazila = upazila.trim(),
            waqfRegNo = waqfRegNo.trim(),
            capacity = capacity,
            bankAccountInfo = bankAccountInfo.trim(),
            logoUrl = mosqueLogoUri
        )

        val president = MemberEntity(
            id = presidentId,
            memberCode = "MEM-001",
            nameBn = presidentNameBn,
            nameEn = presidentNameEn.ifBlank { presidentNameBn },
            mobile = presidentMobile,
            email = presidentEmail,
            nid = presidentNid,
            address = address,
            villageArea = upazila.trim().ifBlank { address.substringBefore(",").ifBlank { "সদর" } },
            roleCode = "president",
            monthlyChanda = presidentMonthlyChanda,
            joinDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
            photoUrl = presidentPhotoUri,
            status = "active",
            willingToProvideStaffMeals = willingToProvideStaffMeals
        )

        val success = repository.registerNewMosqueAndPresident(mosqueEntity, president)
        return if (success) {
            sessionManager.saveRegisteredCredential(
                mobile = presidentMobile,
                committeeId = committeeId,
                mosqueId = mosqueId,
                password = password
            )
            sessionManager.saveRegisteredPresidentEmailCredential(
                email = presidentEmail,
                committeeId = committeeId,
                mosqueId = mosqueId,
                password = password
            )
            // Create the JWT-linked profile BEFORE pushing the mosque: every
            // other RLS policy resolves the tenant through this profile.
            val credentialSync = SupabaseSyncManager.syncPresidentCredential(
                context = getApplication(),
                mosqueId = mosqueId,
                memberId = presidentId,
                email = cleanAuthEmail,
                mobile = presidentMobile,
                nameBn = presidentNameBn,
                plainPass = password,
                authUserId = authSession.uid
            )
            if (credentialSync.isFailure) {
                sessionManager.clearAuthSession()
                return Result.failure(Exception(
                    "ক্লাউড প্রোফাইল তৈরি ব্যর্থ: ${credentialSync.exceptionOrNull()?.message ?: "অজানা ত্রুটি"}"
                ))
            }
            sessionManager.saveActiveMosqueId(mosqueId)
            _activeMosqueId.value = mosqueId
            _currentUserRole.value = UserRole.PRESIDENT
            _isLoggedIn.value = true
            sessionManager.saveSession(
                role = UserRole.PRESIDENT,
                memberId = presidentId,
                memberName = presidentNameBn,
                committeeId = committeeId,
                mobile = presidentMobile,
                rememberMe = true,
                mosqueId = mosqueId
            )
            // Registration must reach the cloud even if it happens right after
            // launch (inside the realtime sync cooldown).
            restartRealtime()
            triggerImmediateCloudSync(force = true)
            Result.success(committeeId)
        } else {
            Result.failure(Exception("রেজিস্ট্রেশন সংরক্ষণ করা সম্ভব হয়নি"))
        }
    }

    fun login(committeeId: String, mobile: String, pass: String): Boolean {
        _isLoggedIn.value = true
        return true
    }

    fun logout() {
        sessionManager.clearSession()
        SupabaseRealtimeClient.stop()
        _readNotificationIds.value = emptySet()
        _activeMosqueId.value = ""
        _isLoggedIn.value = false
        _currentUserRole.value = UserRole.GENERAL_MEMBER
    }

    fun purgeDemoData(onComplete: () -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            val db = MosqueDatabase.getDatabase(getApplication(), viewModelScope)
            DatabaseInitializer.purgeDemoDataIfPresent(db, getApplication())
            withContext(Dispatchers.Main) {
                logout()
                onComplete()
            }
        }
    }


    // Mosque
    val mosque: StateFlow<MosqueEntity?> = _activeMosqueId
        .flatMapLatest { id ->
            repository.getMosqueById(id).flatMapLatest { byId ->
                if (byId != null) flowOf(byId) else repository.mosque
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentMosque: StateFlow<MosqueEntity?> = mosque

    // --- Firebase AI Logic (Gemini 3.8 Flash) ---
    private val noticeSchema = Schema.obj(
        properties = mapOf(
            "title" to Schema.string(description = "A concise, formal Bengali mosque notice title"),
            "content" to Schema.string(description = "Professional Islamic-toned Bengali notice body starting with Bismillah and ending with Mosque Committee signature")
        )
    )

    // Replay-protected (limited-use) App Check tokens are REQUIRED by Firebase AI Logic
    // since 2 Nov 2026. Without this, every request is rejected with HTTP 403 even with
    // a valid google-services.json — the main reason "AI was not working".
    private val firebaseAi by lazy {
        Firebase.ai(useLimitedUseAppCheckTokens = true)
    }

    private val noticeDraftModel by lazy {
        firebaseAi.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = noticeSchema
            }
        )
    }

    private val summaryModel by lazy {
        firebaseAi.generativeModel("gemini-3.8-flash")
    }

    private val _aiNoticeState = MutableStateFlow<AiNoticeUiState>(AiNoticeUiState.Idle)
    val aiNoticeState: StateFlow<AiNoticeUiState> = _aiNoticeState.asStateFlow()

    private val _aiSummaryState = MutableStateFlow<AiSummaryUiState>(AiSummaryUiState.Idle)
    val aiSummaryState: StateFlow<AiSummaryUiState> = _aiSummaryState.asStateFlow()

    fun clearAiNoticeState() {
        _aiNoticeState.value = AiNoticeUiState.Idle
    }

    fun clearAiSummaryState() {
        _aiSummaryState.value = AiSummaryUiState.Idle
    }

    fun draftNoticeWithAi(instruction: String) {
        val cleanInstruction = instruction.trim()
        if (cleanInstruction.isBlank()) {
            _aiNoticeState.value = AiNoticeUiState.Error("অনুগ্রহ করে নোটিশের সংক্ষিপ্ত নির্দেশনা লিখুন।")
            return
        }
        val activeMosqueName = mosque.value?.nameBn ?: "মসজিদ সেবা"
        val activeMosqueAddress = mosque.value?.address ?: "ঢাকা"

        viewModelScope.launch {
            _aiNoticeState.value = AiNoticeUiState.Loading
            try {
                val prompt = """
                    আপনি "$activeMosqueName" ($activeMosqueAddress)-এর দাপ্তরিক নোটিশ সহকারী।
                    নিচের সংক্ষিপ্ত নির্দেশনা থেকে মুসল্লি ও কমিটির জন্য মার্জিত, ইসলামিক ও দাপ্তরিক বাংলায় একটি নোটিশের শিরোনাম (title) এবং বিস্তারিত নোটিশ (content) তৈরি করুন।
                    বিস্তারিত নোটিশ "বিসমিল্লাহির রাহমানির রাহিম" দিয়ে শুরু করে "— মসজিদ পরিচালনা কমিটি, $activeMosqueName" দিয়ে শেষ করবেন।
                    নির্দেশনা: $cleanInstruction
                """.trimIndent()

                val response = withTimeout(60_000L) {
                    noticeDraftModel.generateContent(prompt)
                }
                val jsonString = response.text
                if (jsonString.isNullOrBlank()) {
                    _aiNoticeState.value = AiNoticeUiState.Error("জেমিনি মডেল থেকে কোনো খসড়া পাওয়া যায়নি।")
                    return@launch
                }
                val json = JSONObject(jsonString)
                val draftedTitle = json.getString("title")
                val draftedContent = json.getString("content")
                _aiNoticeState.value = AiNoticeUiState.Success(
                    title = draftedTitle,
                    content = draftedContent
                )
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI notice drafting timed out", e)
                _aiNoticeState.value = AiNoticeUiState.Error("৬০ সেকেন্ডে কোনো উত্তর পাওয়া যায়নি। অনুগ্রহ করে আবার চেষ্টা করুন।")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Firebase AI notice drafting failed", e)
                _aiNoticeState.value = AiNoticeUiState.Error(friendlyAiError(e))
            }
        }
    }

    fun generateFinanceSummaryWithAi() {
        val activeMosqueName = mosque.value?.nameBn ?: "মসজিদ সেবা"
        val inc = totalIncome.value
        val exp = totalExpense.value
        val bal = netBalance.value
        val pendingCount = pendingTransactions.value.size
        val approvedCount = allTransactions.value.count { it.approvalStatus == "approved" }
        val chanda = totalChandaCollected.value

        viewModelScope.launch {
            _aiSummaryState.value = AiSummaryUiState.Loading
            val accumulated = StringBuilder()
            try {
                val prompt = """
                    আপনি "$activeMosqueName"-এর স্বচ্ছ আর্থিক প্রতিবেদনের সহকারী।
                    নিচের বাস্তব হিসাবের উপর ভিত্তি করে ৩-৪টি সংক্ষিপ্ত বুলেট পয়েন্টে বাংলায় একটি পরিচ্ছন্ন ও স্বচ্ছ আর্থিক সারসংক্ষেপ লিখুন (কোনো সংখ্যা বানাবেন না):
                    - মোট অনুমোদিত আয়: ৳${String.format(Locale.US, "%,.0f", inc)}
                    - মোট অনুমোদিত ব্যয়: ৳${String.format(Locale.US, "%,.0f", exp)}
                    - বর্তমান নিট তহবিল ব্যালেন্স: ৳${String.format(Locale.US, "%,.0f", bal)}
                    - মোট সদস্য চাঁদা আদায়: ৳${String.format(Locale.US, "%,.0f", chanda)}
                    - অনুমোদিত লেনদেন: $approvedCount টি
                    - অনুমোদনের অপেক্ষায়: $pendingCount টি
                """.trimIndent()

                withTimeout(60_000L) {
                    summaryModel.generateContentStream(prompt).collect { chunk ->
                        accumulated.append(chunk.text.orEmpty())
                        _aiSummaryState.value = AiSummaryUiState.Streaming(accumulated.toString())
                    }
                }
                if (accumulated.isNotBlank()) {
                    _aiSummaryState.value = AiSummaryUiState.Success(accumulated.toString())
                } else {
                    _aiSummaryState.value = AiSummaryUiState.Error("এআই সারসংক্ষেপ খালি এসেছে।")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI finance summary timed out", e)
                _aiSummaryState.value = AiSummaryUiState.Error("আর্থিক সারসংক্ষেপ তৈরিতে সময় শেষ হয়েছে।")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Firebase AI finance summary failed", e)
                _aiSummaryState.value = AiSummaryUiState.Error(friendlyAiError(e))
            }
        }
    }

    private val _aiEventGuidanceState = MutableStateFlow<AiEventGuidanceUiState>(AiEventGuidanceUiState.Idle)
    val aiEventGuidanceState: StateFlow<AiEventGuidanceUiState> = _aiEventGuidanceState.asStateFlow()

    fun clearEventAiGuidance() {
        _aiEventGuidanceState.value = AiEventGuidanceUiState.Idle
    }

    fun generateEventAiGuidance(event: IslamicEvent) {
        val activeMosqueName = mosque.value?.nameBn ?: "মসজিদ সেবা"
        val activeMosqueAddress = mosque.value?.address ?: "ঢাকা"

        viewModelScope.launch {
            _aiEventGuidanceState.value = AiEventGuidanceUiState.Loading
            try {
                val prompt = """
                    আপনি "$activeMosqueName" ($activeMosqueAddress)-এর খতিব ও ইসলামিক গবেষণা সহযোগী।
                    আসন্ন বা চলমান পবিত্র উপলক্ষ: "${event.titleBn} (${event.titleEn})"
                    আরবি মাস ও তারিখ: ${event.dateRangeBn}
                    মূল তাৎপর্য: ${event.defaultSignificanceBn}
                    
                    অনুগ্রহ করে খতিব সাহেব ও সাধারণ মুসল্লিদের জন্য অত্যন্ত মার্জিত, প্রামাণ্য (কুরআন ও সুন্নাহ ভিত্তিক) বাংলায় একটি পূর্ণাঙ্গ দিকনির্দেশনা তৈরি করুন। এতে অন্তর্ভুক্ত থাকবে:
                    ১. কুরআন ও সহিহ হাদিসের আলোকে এই দিবসের ফজিলত ও গুরুত্ব।
                    ২. সাধারণ মুসল্লিদের জন্য বিশেষ করণীয় নফল আমল, দোয়া ও জিকিরসমূহ (এবং বর্জনীয় বিদআত/কুসংস্কার)।
                    ৩. ইমাম ও খতিবদের জন্য জুমার বয়ান বা মাহফিলের ৩-৪টি শক্তিশালী পয়েন্ট ও পয়েন্টভিত্তিক মূল বক্তব্য।
                    ৪. সমাজের অভাবী মানুষ ও পাড়া-প্রতিবেশীর হক আদায়ে বিশেষ দিকনির্দেশনা।
                    
                    ভাষা হবে আবেগময়, প্রামাণ্য ও উৎসাহব্যঞ্জক। অপ্রয়োজনীয় ভূমিকা পরিহার করে সরাসরি বিষয়বস্তু তুলে ধরুন।
                """.trimIndent()

                val response = withTimeout(60_000L) {
                    summaryModel.generateContent(prompt)
                }
                val text = response.text
                if (text.isNullOrBlank()) {
                    _aiEventGuidanceState.value = AiEventGuidanceUiState.Error(
                        "এআই থেকে কোনো দিকনির্দেশনা পাওয়া যায়নি। আবার চেষ্টা করুন।"
                    )
                } else {
                    _aiEventGuidanceState.value = AiEventGuidanceUiState.Success(
                        eventId = event.id,
                        fullGuidanceText = text.trim()
                    )
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI event guidance timed out", e)
                _aiEventGuidanceState.value = AiEventGuidanceUiState.Error(
                    "৬০ সেকেন্ডে উত্তর পাওয়া যায়নি। ইন্টারনেট সংযোগ যাচাই করে আবার চেষ্টা করুন।"
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Firebase AI event guidance failed", e)
                _aiEventGuidanceState.value = AiEventGuidanceUiState.Error(friendlyAiError(e))
            }
        }
    }

    // --- AI: Islamic Dawatnama / invitation poster description ---
    private val _aiDawatnamaState = MutableStateFlow<AiDawatnamaUiState>(AiDawatnamaUiState.Idle)
    val aiDawatnamaState: StateFlow<AiDawatnamaUiState> = _aiDawatnamaState.asStateFlow()

    fun clearAiDawatnamaState() {
        _aiDawatnamaState.value = AiDawatnamaUiState.Idle
    }

    fun generateDawatnamaDescription(
        mosqueName: String,
        mosqueAddress: String,
        eventType: String,
        title: String,
        chiefGuest: String,
        date: String,
        time: String,
        venue: String
    ) {
        viewModelScope.launch {
            _aiDawatnamaState.value = AiDawatnamaUiState.Loading
            try {
                val prompt = """
                    আপনি "$mosqueName" ($mosqueAddress)-এর দাওয়াতনামা ও মাহফিল উপলক্ষে দাপ্তরিক বাংলা লেখক।
                    নিচের তথ্য ব্যবহার করে খুবই মার্জিত, আন্তরিক ও ইসলামিক শিষ্টাচারসম্পন্ন একটি বর্ণনা (description) রচনা করুন।
                    শুরুতে "বিসমিল্লাহির রাহমানির রাহিম" লিখবেন এবং শেষে "— $mosqueName পরিচালনা কমিটি" দিয়ে শেষ করবেন।
                    কোনো বানানো সংখ্যা, তারিখ বা নাম যোগ করবেন না; শুধু নিচের তথ্যই ব্যবহার করুন।

                    অনুষ্ঠানের ধরন: $eventType
                    শিরোনাম: $title
                    প্রধান অতিথি: ${chiefGuest.ifBlank { "উল্লেখ নেই" }}
                    তারিখ: $date
                    সময়: $time
                    স্থান: $venue

                    বাংলা উত্তর শুধু বর্ণনাটিই দিন, কোনো ব্যাখ্যা বা শিরোনাম ছাড়া।
                """.trimIndent()

                val response = withTimeout(60_000L) {
                    summaryModel.generateContent(prompt)
                }
                val text = response.text?.trim()
                if (text.isNullOrBlank()) {
                    _aiDawatnamaState.value = AiDawatnamaUiState.Error(
                        "এআই থেকে কোনো বর্ণনা পাওয়া যায়নি। আবার চেষ্টা করুন।"
                    )
                } else {
                    _aiDawatnamaState.value = AiDawatnamaUiState.Success(text)
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI dawatnama timed out", e)
                _aiDawatnamaState.value = AiDawatnamaUiState.Error(
                    "৬০ সেকেন্ডে উত্তর পাওয়া যায়নি। আবার চেষ্টা করুন।"
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Firebase AI dawatnama failed", e)
                _aiDawatnamaState.value = AiDawatnamaUiState.Error(friendlyAiError(e))
            }
        }
    }

    // Members & search
    val allMembers: StateFlow<List<MemberEntity>> = repository.allMembers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeMemberCount: StateFlow<Int> = repository.activeMemberCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val memberCount: StateFlow<Int> = repository.memberCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _memberSearchQuery = MutableStateFlow("")
    val memberSearchQuery: StateFlow<String> = _memberSearchQuery.asStateFlow()

    private val _selectedRoleFilter = MutableStateFlow<String?>(null)
    val selectedRoleFilter: StateFlow<String?> = _selectedRoleFilter.asStateFlow()

    val filteredMembers: StateFlow<List<MemberEntity>> = combine(
        allMembers,
        _memberSearchQuery,
        _selectedRoleFilter
    ) { list, query, roleFilter ->
        list.filter { member ->
            val matchesQuery = query.isBlank() ||
                    member.nameBn.contains(query, ignoreCase = true) ||
                    member.nameEn.contains(query, ignoreCase = true) ||
                    member.memberCode.contains(query, ignoreCase = true) ||
                    member.mobile.contains(query)
            val matchesRole = roleFilter == null || member.roleCode.equals(roleFilter, ignoreCase = true)
            matchesQuery && matchesRole
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setMemberSearchQuery(query: String) {
        _memberSearchQuery.value = query
    }

    fun setSelectedRoleFilter(role: String?) {
        _selectedRoleFilter.value = role
    }

    /**
     * Every member gets a real Supabase Auth account. The UI still uses mobile
     * + password (default = last six mobile digits); we map the immutable
     * member ID to a synthetic email that Auth understands.
     */
    private suspend fun createAuthAccountForMember(member: MemberEntity) {
        val digits = member.mobile.filter { it.isDigit() }
        val initialPassword = if (digits.length >= 6) digits.takeLast(6) else "123456"
        val authEmail = SupabaseAuthClient.syntheticEmail(member.id)
        val result = SupabaseAuthClient(getApplication()).signUp(authEmail, initialPassword)
        if (result.isFailure) {
            Log.w(TAG, "Member Auth signup failed: ${result.exceptionOrNull()?.message}")
            return
        }
        val session = result.getOrNull() ?: return
        val mosqueId = _activeMosqueId.value.ifBlank { sessionManager.getActiveMosqueId() }
        val linked = SupabaseSyncManager.syncMemberCredential(
            context = getApplication(),
            mosqueId = mosqueId,
            memberId = member.id,
            authUserId = session.uid,
            email = authEmail,
            mobile = member.mobile,
            nameBn = member.nameBn,
            plainPass = initialPassword
        )
        if (linked.isFailure) {
            Log.w(TAG, "Member profile link failed: ${linked.exceptionOrNull()?.message}")
        }
        sessionManager.saveRegisteredCredential(
            mobile = member.mobile.replace("-", "").replace(" ", "").trim(),
            committeeId = mosque.value?.committeeId ?: sessionManager.getSavedCommitteeId(),
            mosqueId = mosqueId,
            password = initialPassword
        )
    }

    fun addMember(
        nameBn: String,
        nameEn: String,
        mobile: String,
        email: String,
        nid: String,
        address: String,
        villageArea: String,
        roleCode: String,
        monthlyChanda: Double,
        photoUrl: String? = null,
        willingToProvideStaffMeals: Boolean = false,
        salaryAmount: Double = 0.0,
        staffMealRequired: Boolean = true
    ) {
        viewModelScope.launch {
            val maxNum = allMembers.value.mapNotNull {
                it.memberCode.removePrefix("MEM-").toIntOrNull()
            }.maxOrNull() ?: 100
            val newCode = "MEM-${maxNum + 1}"
            val joinDateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val memberId = UUID.randomUUID().toString()
            val member = MemberEntity(
                id = memberId,
                memberCode = newCode,
                nameBn = nameBn,
                nameEn = nameEn,
                mobile = mobile,
                email = email,
                nid = nid,
                address = address,
                villageArea = villageArea,
                roleCode = roleCode,
                monthlyChanda = monthlyChanda,
                joinDate = joinDateStr,
                photoUrl = photoUrl,
                status = "active",
                willingToProvideStaffMeals = willingToProvideStaffMeals
            )
            repository.addMember(member)
            withContext(Dispatchers.IO) { createAuthAccountForMember(member) }
            syncStaffForMember(
                member = member,
                salaryAmount = salaryAmount,
                staffMealRequired = staffMealRequired
            )
            triggerImmediateCloudSync()
        }
    }

    // Finance & Transactions
    val allTransactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingTransactions: StateFlow<List<TransactionEntity>> = repository.pendingTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalIncome: StateFlow<Double> = repository.totalIncome
        .map { it ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalExpense: StateFlow<Double> = repository.totalExpense
        .map { it ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val netBalance: StateFlow<Double> = combine(totalIncome, totalExpense) { inc, exp ->
        inc - exp
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun addTransaction(
        categoryNameBn: String,
        type: String,
        amount: Double,
        description: String,
        sourceType: String = "manual",
        paymentMethod: String = "cash"
    ) {
        viewModelScope.launch {
            val nextNum = allTransactions.value.size + 1
            val currentYear = Calendar.getInstance().get(Calendar.YEAR)
            val code = "TXN-$currentYear-${String.format(Locale.US, "%03d", nextNum)}"
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val role = _currentUserRole.value

            // Approval policy: President / Vice President creates auto-approved up to 50k; others pending
            val status = if (role.canApproveFinance() && amount <= 50000) "approved" else "pending"
            val approvedBy = if (status == "approved") role.titleBn else null
            val resolvedSourceType = if (sourceType == "manual") "manual_$paymentMethod" else sourceType

            val txn = TransactionEntity(
                id = UUID.randomUUID().toString(),
                transactionCode = code,
                categoryNameBn = categoryNameBn,
                type = type,
                amount = amount,
                txnDate = dateStr,
                description = description,
                sourceType = resolvedSourceType,
                createdBy = role.titleBn,
                approvedBy = approvedBy,
                approvalStatus = status
            )
            repository.addTransaction(txn)
            triggerImmediateCloudSync()
        }
    }

    fun updateTransactionStatus(transaction: TransactionEntity, approved: Boolean) {
        viewModelScope.launch {
            val currentName = sessionManager.getSavedMemberName().trim().takeIf { it.isNotBlank() && it != "সদস্য" }
            val approver = if (currentName != null) "${_currentUserRole.value.titleBn} ($currentName)" else _currentUserRole.value.titleBn
            val newStatus = if (approved) "approved" else "rejected"
            repository.updateTransactionStatus(transaction, newStatus, approver)
            triggerImmediateCloudSync(force = true)
        }
    }

    // Chanda payments
    val allChandaPayments: StateFlow<List<ChandaPaymentEntity>> = repository.allChandaPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalChandaCollected: StateFlow<Double> = repository.totalChandaCollected
        .map { it ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val dueChanda: StateFlow<Double> = combine(allMembers, totalChandaCollected) { members, collected ->
        val expectedMonthly = members.filter { it.status == "active" }.sumOf { it.monthlyChanda }
        (expectedMonthly - collected).coerceAtLeast(0.0)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun recordChandaPayment(
        member: MemberEntity,
        month: String,
        amount: Double,
        method: String,
        selectedMonthCount: Int = 1,
        onRecorded: ((ChandaPaymentEntity) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val currentYear = Calendar.getInstance().get(Calendar.YEAR)
            val commId = mosque.value?.committeeId ?: "MS"
            val rcpNum = allChandaPayments.value.size + 101
            val rcpCode = "RCP-$currentYear-$rcpNum"
            val qrCode = "VER-$commId-$rcpNum-${UUID.randomUUID().toString().take(6).uppercase()}"
            val cal = Calendar.getInstance()
            val amPm = if (cal.get(Calendar.AM_PM) == Calendar.AM) "পূর্বাহ্ণ" else "অপরাহ্ণ"
            val paidAtStr = toBengaliDigits("${SimpleDateFormat("yyyy-MM-dd hh:mm", Locale.getDefault()).format(cal.time)} $amPm")
            val monthCount = selectedMonthCount.coerceAtLeast(1)
            val expectedDue = (member.monthlyChanda * monthCount).coerceAtLeast(member.monthlyChanda)
            val payment = ChandaPaymentEntity(
                id = UUID.randomUUID().toString(),
                memberId = member.id,
                memberNameBn = member.nameBn,
                month = month,
                amountDue = expectedDue,
                amountPaid = amount,
                method = method,
                status = if (amount >= expectedDue) "paid" else "partial",
                receiptCode = rcpCode,
                qrVerificationCode = qrCode,
                receivedBy = _currentUserRole.value.titleBn,
                paidAt = paidAtStr
            )
            repository.recordChandaPayment(payment)
            // Push the chanda payment AND its auto-posted income transaction to the
            // cloud immediately. Without this, no postgres_changes event is emitted,
            // so no other device (including the member) ever sees a live update.
            triggerImmediateCloudSync(force = true)
            if (sessionManager.isNotificationsEnabled()) {
                MosquePushNotificationHelper.postChandaReceiptNotification(getApplication(), payment)
            }
            onRecorded?.invoke(payment)
        }
    }

    // Staff
    val activeStaff: StateFlow<List<StaffEntity>> = repository.activeStaff
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addStaff(
        nameBn: String,
        roleCode: String,
        designationBn: String,
        salaryAmount: Double,
        mobile: String
    ) {
        viewModelScope.launch {
            val staff = StaffEntity(
                id = UUID.randomUUID().toString(),
                nameBn = nameBn,
                roleCode = roleCode,
                designationBn = designationBn,
                joinDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                salaryAmount = salaryAmount,
                mobile = mobile
            )
            repository.addStaff(staff)
        }
    }

    // Notices
    val allNotices: StateFlow<List<NoticeEntity>> = repository.allNotices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun publishNotice(title: String, content: String, priority: String, isPinned: Boolean, imageUrl: String? = null) {
        viewModelScope.launch {
            val dateStr = SimpleDateFormat("dd MMMM yyyy", Locale.forLanguageTag("bn-BD")).format(Date())
            val notice = NoticeEntity(
                id = UUID.randomUUID().toString(),
                title = title,
                content = content,
                priority = priority,
                isPinned = isPinned,
                publishDate = dateStr,
                createdBy = "${_currentUserRole.value.titleBn}",
                imageUrl = imageUrl
            )
            repository.addNotice(notice)
            if (sessionManager.isNotificationsEnabled()) {
                MosquePushNotificationHelper.postNoticeNotification(getApplication(), notice)
            }
        }
    }

    fun updateNotice(
        notice: NoticeEntity,
        title: String,
        content: String,
        priority: String,
        isPinned: Boolean,
        imageUrl: String? = notice.imageUrl
    ) {
        viewModelScope.launch {
            val updated = notice.copy(
                title = title,
                content = content,
                priority = priority,
                isPinned = isPinned,
                imageUrl = imageUrl
            )
            repository.updateNotice(updated)
        }
    }

    fun togglePinNotice(notice: NoticeEntity) {
        viewModelScope.launch {
            val updated = notice.copy(isPinned = !notice.isPinned)
            val action = if (updated.isPinned) "NOTICE_PINNED" else "NOTICE_UNPINNED"
            val details = if (updated.isPinned) "নোটিশ পিন করা হয়েছে: ${notice.title}" else "নোটিশ আনপিন করা হয়েছে: ${notice.title}"
            repository.updateNotice(updated, action, details)
        }
    }

    fun deleteNotice(notice: NoticeEntity) {
        viewModelScope.launch {
            repository.deleteNotice(notice)
        }
    }

    // Meetings
    val allMeetings: StateFlow<List<MeetingEntity>> = repository.allMeetings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun scheduleMeeting(title: String, dateStr: String, location: String, agenda: String) {
        viewModelScope.launch {
            val meeting = MeetingEntity(
                id = UUID.randomUUID().toString(),
                title = title,
                meetingDate = dateStr,
                location = location,
                agenda = agenda,
                status = "upcoming"
            )
            repository.addMeeting(meeting)
            if (sessionManager.isNotificationsEnabled()) {
                MosquePushNotificationHelper.postMeetingNotification(getApplication(), meeting)
            }
        }
    }

    fun updateMeeting(
        meeting: MeetingEntity,
        title: String,
        dateStr: String,
        location: String,
        agenda: String
    ) {
        viewModelScope.launch {
            val updated = meeting.copy(
                title = title,
                meetingDate = dateStr,
                location = location,
                agenda = agenda
            )
            repository.updateMeeting(updated)
        }
    }

    fun toggleMeetingStatus(meeting: MeetingEntity) {
        viewModelScope.launch {
            val nextStatus = if (meeting.status == "completed") "upcoming" else "completed"
            val updated = meeting.copy(status = nextStatus)
            val action = if (nextStatus == "completed") "MEETING_COMPLETED" else "MEETING_REOPENED"
            val details = if (nextStatus == "completed") "সভা সম্পন্ন হিসেবে চিহ্নিত: ${meeting.title}" else "সভা পুনরায় আসন্ন হিসেবে চিহ্নিত: ${meeting.title}"
            repository.updateMeeting(updated, action, details)
        }
    }

    fun saveMeetingResolution(
        meeting: MeetingEntity,
        resolution: String,
        markCompleted: Boolean
    ) {
        viewModelScope.launch {
            val nextStatus = if (markCompleted) "completed" else meeting.status
            val updated = meeting.copy(
                resolution = resolution.trim(),
                status = nextStatus
            )
            repository.updateMeeting(
                updated,
                auditAction = "MEETING_RESOLUTION_SAVED",
                auditDetails = "সভার সিদ্ধান্ত/কার্যবিবরণী সংরক্ষিত: ${meeting.title}"
            )
        }
    }

    fun deleteMeeting(meeting: MeetingEntity) {
        viewModelScope.launch {
            repository.deleteMeeting(meeting)
        }
    }

    // Audit logs
    val recentAuditLogs: StateFlow<List<AuditLogEntity>> = repository.recentAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- মাদরাসা ও মক্তব স্টেট ও অ্যাকশন (PRD §16–§24) ---
    val allStudents: StateFlow<List<StudentEntity>> = repository.allStudents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val studentCount: StateFlow<Int> = repository.studentCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun getAttendanceByDate(date: String): Flow<List<MadrasaAttendanceEntity>> =
        repository.getAttendanceByDate(date)

    fun getAttendanceForStudent(studentId: String): Flow<List<MadrasaAttendanceEntity>> =
        repository.getAttendanceForStudent(studentId)

    fun recordAttendanceBatch(attendanceList: List<MadrasaAttendanceEntity>) {
        viewModelScope.launch {
            repository.recordAttendanceBatch(attendanceList)
        }
    }

    fun addStudent(
        nameBn: String,
        className: String,
        guardianName: String,
        guardianMobile: String,
        monthlyFee: Double
    ) {
        viewModelScope.launch {
            val codeNum = allStudents.value.size + 1
            val currentYear = Calendar.getInstance().get(Calendar.YEAR)
            val code = "STU-$currentYear-${String.format(Locale.US, "%03d", codeNum)}"
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val student = StudentEntity(
                id = UUID.randomUUID().toString(),
                studentCode = code,
                nameBn = nameBn,
                className = className,
                guardianName = guardianName,
                guardianMobile = guardianMobile,
                monthlyFee = monthlyFee,
                joinDate = dateStr
            )
            repository.addStudent(student)
        }
    }

    fun updateStudent(student: StudentEntity) {
        viewModelScope.launch {
            repository.updateStudent(student)
        }
    }

    val allHifzProgress: StateFlow<List<HifzProgressEntity>> = repository.allHifzProgress
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addHifzProgress(
        student: StudentEntity,
        paraNumber: Int,
        pageOrAyah: String,
        qualityScore: Int,
        mistakeCount: Int,
        feedback: String
    ) {
        viewModelScope.launch {
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val progress = HifzProgressEntity(
                id = UUID.randomUUID().toString(),
                studentId = student.id,
                studentNameBn = student.nameBn,
                date = dateStr,
                paraNumber = paraNumber,
                pageOrAyah = pageOrAyah,
                qualityScore = qualityScore,
                mistakeCount = mistakeCount,
                teacherFeedback = feedback
            )
            repository.addHifzProgress(progress)
        }
    }

    val allFeePayments: StateFlow<List<MadrasaFeePaymentEntity>> = repository.allFeePayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalFeeCollected: StateFlow<Double> = repository.totalFeeCollected
        .map { it ?: 0.0 }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun recordMadrasaFee(
        student: StudentEntity,
        month: String,
        amount: Double,
        method: String = "cash"
    ) {
        viewModelScope.launch {
            val currentYear = Calendar.getInstance().get(Calendar.YEAR)
            val rcpCode = "FEE-$currentYear-${UUID.randomUUID().toString().take(6).uppercase()}"
            val cal = Calendar.getInstance()
            val amPm = if (cal.get(Calendar.AM_PM) == Calendar.AM) "পূর্বাহ্ণ" else "অপরাহ্ণ"
            val paidAtStr = toBengaliDigits("${SimpleDateFormat("yyyy-MM-dd hh:mm", Locale.getDefault()).format(cal.time)} $amPm")
            val fee = MadrasaFeePaymentEntity(
                id = UUID.randomUUID().toString(),
                studentId = student.id,
                studentNameBn = student.nameBn,
                month = month,
                amountPaid = amount,
                receiptCode = rcpCode,
                paymentMethod = method,
                paidAt = paidAtStr
            )
            repository.recordMadrasaFeePayment(fee)
        }
    }

    // --- স্টাফ পে-রোল, রোস্টার ও ফুড শিডিউল (PRD §10–§12) ---
    val allPayrolls: StateFlow<List<StaffPayrollEntity>> = repository.allPayrolls
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun disburseSalary(
        staff: StaffEntity,
        month: String,
        bonus: Double = 0.0,
        paymentMethod: String = "cash",
        onDisbursed: ((StaffPayrollEntity) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val baseSalary = if (staff.salaryAmount > 0.0) staff.salaryAmount else {
                when (staff.roleCode.lowercase()) {
                    "imam" -> 18000.0
                    "muazzin" -> 12000.0
                    else -> 9000.0
                }
            }
            if (staff.salaryAmount <= 0.0) {
                repository.updateStaff(staff.copy(salaryAmount = baseSalary))
            }
            val existsInDb = activeStaff.value.any { it.id == staff.id }
            if (!existsInDb) {
                repository.addStaff(staff.copy(salaryAmount = baseSalary, isActive = true))
            }
            val net = baseSalary + bonus
            val payroll = StaffPayrollEntity(
                id = UUID.randomUUID().toString(),
                staffId = staff.id,
                staffNameBn = staff.nameBn,
                month = month,
                salaryAmount = baseSalary,
                bonusAmount = bonus,
                netSalary = net,
                paymentStatus = "paid",
                paidDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            )
            repository.disburseStaffSalary(
                payroll = payroll,
                paidBy = _currentUserRole.value.titleBn,
                paymentMethod = paymentMethod
            )
            onDisbursed?.invoke(payroll)
        }
    }

    val allDutyRosters: StateFlow<List<DutyRosterEntity>> = repository.allDutyRosters
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addDutyRoster(
        staff: StaffEntity,
        dayOfWeek: String,
        prayerName: String,
        roleTitle: String,
        notes: String
    ) {
        viewModelScope.launch {
            val roster = DutyRosterEntity(
                id = UUID.randomUUID().toString(),
                staffId = staff.id,
                staffNameBn = staff.nameBn,
                dayOfWeek = dayOfWeek,
                prayerName = prayerName,
                roleTitle = roleTitle,
                notes = notes
            )
            repository.addDutyRoster(roster)
        }
    }

    val allFoodSchedules: StateFlow<List<FoodScheduleEntity>> = repository.allFoodSchedules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun normalizeDigitsToAscii(input: String): String {
        val bnDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
        val sb = StringBuilder(input.length)
        for (ch in input) {
            val idx = bnDigits.indexOf(ch)
            if (idx >= 0) sb.append(('0' + idx)) else sb.append(ch)
        }
        return sb.toString()
    }

    fun getOrderedWillingMealDonors(
        members: List<MemberEntity> = allMembers.value,
        schedules: List<FoodScheduleEntity> = allFoodSchedules.value
    ): List<MemberEntity> {
        val willing = members
            .filter { it.status == "active" && it.willingToProvideStaffMeals }
            .sortedBy { it.memberCode }
        if (willing.isEmpty()) return emptyList()

        val activeSchedules = schedules.filter { it.status != "cancelled" && it.status != "rejected" }
        return willing.sortedWith(
            compareBy<MemberEntity> { member ->
                val memberDigits = member.mobile.filter { it.isDigit() }
                val cleanName = member.nameBn.trim()
                activeSchedules.count { food ->
                    val foodDigits = normalizeDigitsToAscii(food.providerMobile).filter { it.isDigit() }
                    (memberDigits.length >= 6 && foodDigits == memberDigits) ||
                        food.providerName.trim().equals(cleanName, ignoreCase = true)
                }
            }.thenBy { it.memberCode }
        )
    }

    fun addFoodSchedule(
        dateStr: String,
        providerName: String,
        providerMobile: String,
        receiverStaffName: String
    ) {
        viewModelScope.launch {
            val food = FoodScheduleEntity(
                id = UUID.randomUUID().toString(),
                dateStr = normalizeDigitsToAscii(dateStr).trim(),
                mealType = "দৈনিক খাবার",
                providerName = providerName,
                providerMobile = providerMobile,
                receiverStaffName = receiverStaffName,
                status = "scheduled"
            )
            repository.addFoodSchedule(food)
        }
    }

    fun autoGenerateFoodSchedule(
        daysCount: Int,
        startDateIso: String,
        targetStaffLabels: List<String>,
        onComplete: (createdCount: Int, skippedCount: Int) -> Unit
    ) {
        viewModelScope.launch {
            val orderedDonors = getOrderedWillingMealDonors()
            if (orderedDonors.isEmpty() || targetStaffLabels.isEmpty()) {
                onComplete(0, 0)
                return@launch
            }

            val activeExisting = allFoodSchedules.value
                .filter { it.status != "cancelled" && it.status != "rejected" }

            // Track already occupied (date -> receiver) and (date -> set of donor keys) so 1 member doesn't feed 2 staff on same day
            val existingDateReceiverPairs = activeExisting
                .map { normalizeDigitsToAscii(it.dateStr).trim() to it.receiverStaffName.trim() }
                .toMutableSet()

            val donorKeysByDate = mutableMapOf<String, MutableSet<String>>()
            activeExisting.forEach { food ->
                val dateKey = normalizeDigitsToAscii(food.dateStr).trim()
                val donorKey = food.providerMobile.filter { it.isDigit() }.ifBlank { food.providerName.trim() }
                donorKeysByDate.getOrPut(dateKey) { mutableSetOf() }.add(donorKey)
            }

            val isoFormat = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
            val parsedStart = runCatching {
                isoFormat.parse(normalizeDigitsToAscii(startDateIso).trim())
            }.getOrNull() ?: Date()

            val calendar = Calendar.getInstance().apply { time = parsedStart }
            val newSchedules = mutableListOf<FoodScheduleEntity>()
            var skippedCount = 0
            var donorCursor = 0

            for (dayOffset in 0 until daysCount) {
                val dateIso = isoFormat.format(calendar.time)
                val usedToday = donorKeysByDate.getOrPut(dateIso) { mutableSetOf() }

                for (staffLabel in targetStaffLabels) {
                    val slotKey = dateIso to staffLabel.trim()
                    val alreadyAssigned = existingDateReceiverPairs.any { (d, r) ->
                        d == dateIso && (r.equals(staffLabel.trim(), ignoreCase = true) ||
                            r.contains(staffLabel.substringBefore(" (").trim(), ignoreCase = true))
                    }
                    if (alreadyAssigned) {
                        skippedCount++
                        continue
                    }

                    // Pick next donor in fair round-robin who isn't already assigned today (when enough donors exist)
                    var pickedDonor: MemberEntity? = null
                    for (attempt in orderedDonors.indices) {
                        val candidate = orderedDonors[(donorCursor + attempt) % orderedDonors.size]
                        val candidateKey = candidate.mobile.filter { it.isDigit() }.ifBlank { candidate.nameBn.trim() }
                        if (candidateKey !in usedToday) {
                            pickedDonor = candidate
                            donorCursor = (donorCursor + attempt + 1) % orderedDonors.size
                            usedToday.add(candidateKey)
                            break
                        }
                    }
                    if (pickedDonor == null) {
                        pickedDonor = orderedDonors[donorCursor % orderedDonors.size]
                        donorCursor = (donorCursor + 1) % orderedDonors.size
                    }

                    existingDateReceiverPairs.add(slotKey)
                    newSchedules.add(
                        FoodScheduleEntity(
                            id = "food-auto-${UUID.randomUUID()}",
                            dateStr = dateIso,
                            mealType = "দৈনিক খাবার",
                            providerName = pickedDonor.nameBn,
                            providerMobile = pickedDonor.mobile,
                            receiverStaffName = staffLabel.trim(),
                            status = "scheduled"
                        )
                    )
                }
                calendar.add(Calendar.DAY_OF_YEAR, 1)
            }

            if (newSchedules.isNotEmpty()) {
                repository.addFoodSchedulesBatch(
                    schedules = newSchedules,
                    actor = _currentUserRole.value.titleBn,
                    summaryNote = "স্বয়ংক্রিয় দৈনিক খাবার শিডিউল: ${newSchedules.size} টি পালা (${daysCount} দিন, ${targetStaffLabels.size} জন স্টাফ, ${orderedDonors.size} জন দাতা)"
                )
            }
            onComplete(newSchedules.size, skippedCount)
        }
    }

    fun approveFoodSchedule(schedule: FoodScheduleEntity) {
        viewModelScope.launch {
            val updated = schedule.copy(status = "approved")
            repository.updateFoodSchedule(
                schedule = updated,
                actor = schedule.providerName,
                auditDetails = "খাবার দায়িত্ব সম্মতি: ${schedule.dateStr} • দাতা: ${schedule.providerName} → ${schedule.receiverStaffName}"
            )
        }
    }

    fun rejectFoodSchedule(
        schedule: FoodScheduleEntity,
        onResult: (reassignedToName: String?) -> Unit = {}
    ) {
        viewModelScope.launch {
            val targetDate = normalizeDigitsToAscii(schedule.dateStr).trim()
            val currentDigits = normalizeDigitsToAscii(schedule.providerMobile).filter { it.isDigit() }
            val usedSameDayKeys = allFoodSchedules.value
                .filter {
                    normalizeDigitsToAscii(it.dateStr).trim() == targetDate &&
                        it.id != schedule.id &&
                        it.status != "cancelled" &&
                        it.status != "rejected"
                }
                .map { normalizeDigitsToAscii(it.providerMobile).filter { d -> d.isDigit() }.ifBlank { it.providerName.trim() } }
                .toSet()

            val orderedDonors = getOrderedWillingMealDonors()
            val alternateDonor = orderedDonors.firstOrNull { donor ->
                val donorDigits = donor.mobile.filter { it.isDigit() }
                val donorKey = donorDigits.ifBlank { donor.nameBn.trim() }
                val isRejectingMember = (currentDigits.length >= 6 && donorDigits == currentDigits) ||
                    donor.nameBn.trim().equals(schedule.providerName.trim(), ignoreCase = true)
                !isRejectingMember && donorKey !in usedSameDayKeys
            }

            if (alternateDonor != null) {
                val reassigned = schedule.copy(
                    providerName = alternateDonor.nameBn,
                    providerMobile = alternateDonor.mobile,
                    status = "scheduled"
                )
                repository.updateFoodSchedule(
                    schedule = reassigned,
                    actor = schedule.providerName,
                    auditDetails = "${schedule.providerName} অপারগতা → স্বয়ংক্রিয়ভাবে ${alternateDonor.nameBn}-কে দায়িত্ব (${schedule.dateStr}, ${schedule.receiverStaffName})"
                )
                onResult(alternateDonor.nameBn)
            } else {
                val rejected = schedule.copy(status = "rejected")
                repository.updateFoodSchedule(
                    schedule = rejected,
                    actor = schedule.providerName,
                    auditDetails = "খাবার দায়িত্ব অপারগতা (বিকল্প প্রয়োজন): ${schedule.dateStr} • ${schedule.providerName} (${schedule.receiverStaffName})"
                )
                onResult(null)
            }
        }
    }

    fun markFoodScheduleDelivered(schedule: FoodScheduleEntity) {
        viewModelScope.launch {
            val updated = schedule.copy(status = "delivered")
            repository.updateFoodSchedule(
                schedule = updated,
                actor = _currentUserRole.value.titleBn,
                auditDetails = "খাবার বিতরণ সম্পন্ন: ${schedule.dateStr} - দাতা: ${schedule.providerName} → ${schedule.receiverStaffName}"
            )
        }
    }

    fun cancelFoodSchedule(schedule: FoodScheduleEntity) {
        viewModelScope.launch {
            val updated = schedule.copy(status = "cancelled")
            repository.updateFoodSchedule(
                schedule = updated,
                actor = _currentUserRole.value.titleBn,
                auditDetails = "খাবার শিডিউল বাতিল: ${schedule.dateStr} - দাতা: ${schedule.providerName} (${schedule.receiverStaffName})"
            )
        }
    }

    fun rotateFoodScheduleDonor(
        schedule: FoodScheduleEntity,
        onRotated: (FoodScheduleEntity?) -> Unit = {}
    ) {
        viewModelScope.launch {
            val orderedDonors = getOrderedWillingMealDonors()
            val targetDate = normalizeDigitsToAscii(schedule.dateStr).trim()
            val currentDigits = normalizeDigitsToAscii(schedule.providerMobile).filter { it.isDigit() }
            val usedSameDayKeys = allFoodSchedules.value
                .filter {
                    normalizeDigitsToAscii(it.dateStr).trim() == targetDate &&
                        it.id != schedule.id &&
                        it.status != "cancelled" &&
                        it.status != "rejected"
                }
                .map { normalizeDigitsToAscii(it.providerMobile).filter { d -> d.isDigit() }.ifBlank { it.providerName.trim() } }
                .toSet()

            val nextDonor = orderedDonors.firstOrNull { donor ->
                val donorDigits = donor.mobile.filter { it.isDigit() }
                val donorKey = donorDigits.ifBlank { donor.nameBn.trim() }
                val sameMobile = currentDigits.length >= 6 && donorDigits == currentDigits
                val sameName = donor.nameBn.trim().equals(schedule.providerName.trim(), ignoreCase = true)
                !sameMobile && !sameName && donorKey !in usedSameDayKeys
            } ?: orderedDonors.firstOrNull { donor ->
                val donorDigits = donor.mobile.filter { it.isDigit() }
                val sameMobile = currentDigits.length >= 6 && donorDigits == currentDigits
                val sameName = donor.nameBn.trim().equals(schedule.providerName.trim(), ignoreCase = true)
                !sameMobile && !sameName
            } ?: orderedDonors.firstOrNull()

            if (nextDonor == null) {
                onRotated(null)
                return@launch
            }

            val updated = schedule.copy(
                providerName = nextDonor.nameBn,
                providerMobile = nextDonor.mobile,
                status = "scheduled"
            )
            repository.updateFoodSchedule(
                schedule = updated,
                actor = _currentUserRole.value.titleBn,
                auditDetails = "খাবার দাতা স্বয়ংক্রিয় পরিবর্তন: ${schedule.dateStr} (${schedule.receiverStaffName}) ${schedule.providerName} → ${nextDonor.nameBn}"
            )
            onRotated(updated)
        }
    }

    fun deleteFoodSchedule(schedule: FoodScheduleEntity) {
        viewModelScope.launch {
            repository.deleteFoodSchedule(
                schedule = schedule,
                actor = _currentUserRole.value.titleBn
            )
        }
    }

    // Welfare & Zakat (PRD §26)
    val allWelfareCases: StateFlow<List<WelfareCaseEntity>> = repository.allWelfareCases
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addWelfareCase(
        beneficiaryName: String,
        category: String,
        mobile: String,
        amountRequested: Double,
        remarks: String = ""
    ) {
        viewModelScope.launch {
            val case = WelfareCaseEntity(
                id = UUID.randomUUID().toString(),
                beneficiaryName = beneficiaryName,
                category = category,
                mobile = mobile,
                amountRequested = amountRequested,
                amountApproved = amountRequested,
                status = "approved",
                applicationDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                remarks = remarks
            )
            repository.addWelfareCase(case)
        }
    }

    fun markWelfareDisbursed(case: WelfareCaseEntity) {
        viewModelScope.launch {
            repository.markWelfareDisbursed(case)
        }
    }

    // Events & Programs (PRD §25)
    val allEvents: StateFlow<List<MosqueEventEntity>> = repository.allEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addEvent(
        title: String,
        dateStr: String,
        timeStr: String,
        speakerOrGuest: String,
        venue: String,
        budget: Double,
        volunteerLead: String
    ) {
        viewModelScope.launch {
            val event = MosqueEventEntity(
                id = UUID.randomUUID().toString(),
                title = title,
                dateStr = dateStr,
                timeStr = timeStr,
                speakerOrGuest = speakerOrGuest,
                venue = venue,
                budget = budget,
                volunteerLead = volunteerLead,
                status = "upcoming"
            )
            repository.addEvent(event)
        }
    }

    // --- Member Management Actions (Permanent ID & Safe Role Switching) ---
    private suspend fun syncStaffForMember(
        member: MemberEntity,
        salaryAmount: Double = 0.0,
        staffMealRequired: Boolean = true
    ) {
        val isStaffRole = member.roleCode.equals("imam", ignoreCase = true) ||
            member.roleCode.equals("muazzin", ignoreCase = true) ||
            member.roleCode.equals("khadem", ignoreCase = true)
        val normMobile = member.mobile.filter { it.isDigit() }
        val existingStaff = activeStaff.value.find { st ->
            st.id == "staff-${member.id}" ||
                (normMobile.length >= 6 && st.mobile.filter { it.isDigit() } == normMobile) ||
                st.nameBn.trim() == member.nameBn.trim()
        }
        val memberActive = member.status == "active"

        if (isStaffRole) {
            val roleTitle = UserRole.fromCode(member.roleCode).titleBn
            if (existingStaff != null) {
                repository.updateStaff(
                    existingStaff.copy(
                        nameBn = member.nameBn,
                        mobile = member.mobile,
                        roleCode = member.roleCode,
                        designationBn = roleTitle,
                        salaryAmount = if (salaryAmount > 0) salaryAmount else existingStaff.salaryAmount,
                        mealRequired = staffMealRequired,
                        isActive = memberActive
                    )
                )
            } else {
                repository.addStaff(
                    StaffEntity(
                        id = "staff-${member.id}",
                        nameBn = member.nameBn,
                        roleCode = member.roleCode,
                        designationBn = roleTitle,
                        joinDate = member.joinDate,
                        salaryAmount = if (salaryAmount > 0) salaryAmount else 12000.0,
                        mealRequired = staffMealRequired,
                        mobile = member.mobile,
                        isActive = memberActive
                    )
                )
            }
        } else if (existingStaff != null && existingStaff.isActive) {
            repository.updateStaff(existingStaff.copy(isActive = false))
        }
    }

    fun updateMemberRole(member: MemberEntity, newRole: UserRole) {
        viewModelScope.launch {
            val updated = member.copy(roleCode = newRole.code)
            repository.updateMember(updated)
            syncStaffForMember(updated)
        }
    }

    fun updateMemberDetails(
        member: MemberEntity,
        salaryAmount: Double = 0.0,
        staffMealRequired: Boolean = true
    ) {
        viewModelScope.launch {
            repository.updateMember(member)
            syncStaffForMember(
                member = member,
                salaryAmount = salaryAmount,
                staffMealRequired = staffMealRequired
            )
        }
    }

    fun toggleMemberStatus(member: MemberEntity) {
        viewModelScope.launch {
            val nextStatus = if (member.status == "active") "inactive" else "active"
            val updated = member.copy(status = nextStatus)
            repository.updateMember(updated)
            syncStaffForMember(updated)
        }
    }

    fun deleteMember(member: MemberEntity) {
        viewModelScope.launch {
            repository.deleteMember(member)
            val normMobile = member.mobile.filter { it.isDigit() }
            activeStaff.value.find { st ->
                st.id == "staff-${member.id}" ||
                    (normMobile.length >= 6 && st.mobile.filter { it.isDigit() } == normMobile) ||
                    st.nameBn.trim() == member.nameBn.trim()
            }?.let { st ->
                repository.updateStaff(st.copy(isActive = false))
            }
        }
    }

    fun updateStaffDetails(staff: StaffEntity) {
        viewModelScope.launch {
            repository.updateStaff(staff)
        }
    }

    fun updateMosqueDetails(updated: MosqueEntity) {
        viewModelScope.launch {
            repository.updateMosqueProfile(updated, _currentUserRole.value.titleBn)
        }
    }

    fun updateMemberSignatureAndStamp(
        memberId: String,
        signatureUrl: String?,
        stampUrl: String?,
        designationBn: String? = null
    ) {
        viewModelScope.launch {
            val existing = allMembers.value.firstOrNull { it.id == memberId } ?: return@launch
            val updated = existing.copy(
                signatureUrl = signatureUrl,
                stampUrl = stampUrl,
                designationBn = designationBn ?: existing.designationBn
            )
            repository.updateMember(updated)
            val normMobile = updated.mobile.filter { it.isDigit() }
            activeStaff.value.find { st ->
                st.id == "staff-${updated.id}" ||
                    (normMobile.length >= 6 && st.mobile.filter { it.isDigit() } == normMobile) ||
                    st.nameBn.trim() == updated.nameBn.trim()
            }?.let { st ->
                repository.updateStaff(st.copy(signatureUrl = signatureUrl, stampUrl = stampUrl))
            }
        }
    }

    fun updateStaffSignatureAndStamp(
        staffId: String,
        signatureUrl: String?,
        stampUrl: String?
    ) {
        viewModelScope.launch {
            val existing = activeStaff.value.firstOrNull { it.id == staffId } ?: return@launch
            repository.updateStaff(existing.copy(signatureUrl = signatureUrl, stampUrl = stampUrl))
            val normMobile = existing.mobile.filter { it.isDigit() }
            allMembers.value.firstOrNull { m ->
                m.id == existing.id.removePrefix("staff-") ||
                    (normMobile.length >= 6 && m.mobile.filter { it.isDigit() } == normMobile) ||
                    m.nameBn.trim() == existing.nameBn.trim()
            }?.let { m ->
                repository.updateMember(m.copy(signatureUrl = signatureUrl, stampUrl = stampUrl))
            }
        }
    }

    fun updateMosqueSeal(sealUrl: String?) {
        viewModelScope.launch {
            val mosque = currentMosque.value ?: return@launch
            repository.updateMosqueProfile(mosque.copy(sealUrl = sealUrl), _currentUserRole.value.titleBn)
        }
    }

    fun getPresidentMember(): MemberEntity? = allMembers.value.firstOrNull { it.roleCode == UserRole.PRESIDENT.code }
    fun getTreasurerMember(): MemberEntity? = allMembers.value.firstOrNull { it.roleCode == UserRole.TREASURER.code }
    fun getSecretaryMember(): MemberEntity? = allMembers.value.firstOrNull { it.roleCode == UserRole.GENERAL_SECRETARY.code }
    fun getImamStaff(): StaffEntity? = activeStaff.value.firstOrNull { it.roleCode == "imam" }

    fun promoteStaffAndUpdateDetails(
        staff: StaffEntity,
        nameBn: String,
        nameEn: String,
        mobile: String,
        email: String,
        nid: String,
        address: String,
        villageArea: String,
        roleCode: String,
        monthlyChanda: Double,
        photoUrl: String?,
        willingToProvideStaffMeals: Boolean,
        salaryAmount: Double,
        staffMealRequired: Boolean
    ) {
        viewModelScope.launch {
            val normMobile = mobile.filter { it.isDigit() }
            val existingMember = allMembers.value.find { m ->
                (normMobile.length >= 6 && m.mobile.filter { it.isDigit() } == normMobile) ||
                    m.nameBn.trim() == staff.nameBn.trim()
            }
            val member = if (existingMember != null) {
                existingMember.copy(
                    nameBn = nameBn,
                    nameEn = nameEn,
                    mobile = mobile,
                    email = email,
                    nid = nid,
                    address = address,
                    villageArea = villageArea,
                    roleCode = roleCode,
                    monthlyChanda = monthlyChanda,
                    photoUrl = photoUrl,
                    willingToProvideStaffMeals = willingToProvideStaffMeals
                )
            } else {
                val maxNum = allMembers.value.mapNotNull {
                    it.memberCode.removePrefix("MEM-").toIntOrNull()
                }.maxOrNull() ?: 100
                MemberEntity(
                    id = UUID.randomUUID().toString(),
                    memberCode = "MEM-${maxNum + 1}",
                    nameBn = nameBn,
                    nameEn = nameEn,
                    mobile = mobile,
                    email = email,
                    nid = nid,
                    address = address,
                    villageArea = villageArea,
                    roleCode = roleCode,
                    monthlyChanda = monthlyChanda,
                    joinDate = staff.joinDate,
                    photoUrl = photoUrl,
                    status = if (staff.isActive) "active" else "inactive",
                    willingToProvideStaffMeals = willingToProvideStaffMeals
                )
            }
            if (existingMember != null) {
                repository.updateMember(member)
            } else {
                repository.addMember(member)
                withContext(Dispatchers.IO) { createAuthAccountForMember(member) }
            }

            val isStaffRole = roleCode.equals("imam", ignoreCase = true) ||
                roleCode.equals("muazzin", ignoreCase = true) ||
                roleCode.equals("khadem", ignoreCase = true)
            if (isStaffRole) {
                val roleTitle = UserRole.fromCode(roleCode).titleBn
                repository.updateStaff(
                    staff.copy(
                        nameBn = nameBn,
                        mobile = mobile,
                        roleCode = roleCode,
                        designationBn = roleTitle,
                        salaryAmount = if (salaryAmount > 0) salaryAmount else staff.salaryAmount,
                        mealRequired = staffMealRequired,
                        isActive = member.status == "active"
                    )
                )
            } else {
                repository.updateStaff(staff.copy(isActive = false))
            }
        }
    }

    fun toggleStaffStatus(staff: StaffEntity) {
        viewModelScope.launch {
            repository.updateStaff(staff.copy(isActive = !staff.isActive))
        }
    }

    fun removeStaff(staff: StaffEntity) {
        viewModelScope.launch {
            repository.updateStaff(staff.copy(isActive = false))
        }
    }

    // --- দান বাক্স (ক্যাশবক্স) সাক্ষী ও ব্যাংক জমা ---
    val allCashboxRecords: StateFlow<List<CashboxRecordEntity>> = repository.allCashboxRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun recordCashboxOpening(
        boxType: String,
        countedAmount: Double,
        witnessNames: String,
        bankName: String,
        depositSlipNo: String,
        notes: String
    ) {
        viewModelScope.launch {
            val role = _currentUserRole.value
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val hasBankDeposit = bankName.isNotBlank() && depositSlipNo.isNotBlank()
            val record = CashboxRecordEntity(
                id = "cb-${UUID.randomUUID().toString().take(8)}",
                collectionDate = dateStr,
                boxType = boxType,
                countedAmount = countedAmount,
                countedBy = role.titleBn,
                witnessNames = witnessNames.ifBlank { "উপস্থিত কার্যনির্বাহী সদস্যবৃন্দ" },
                witnessVerified = false,
                bankName = bankName,
                depositSlipNo = depositSlipNo,
                depositStatus = if (hasBankDeposit) "bank_deposited" else "counted",
                notes = notes
            )
            repository.recordCashboxOpening(record, role.titleBn)
            if (hasBankDeposit) {
                addTransaction(
                    categoryNameBn = boxType,
                    type = "INCOME",
                    amount = countedAmount,
                    description = "$boxType ব্যাংক জমা ($bankName, স্লিপ: $depositSlipNo, সাক্ষী: $witnessNames)",
                    sourceType = "cashbox_deposit"
                )
            }
        }
    }

    fun verifyCashboxAsWitness(record: CashboxRecordEntity) {
        viewModelScope.launch {
            val role = _currentUserRole.value
            val actorName = allMembers.value.firstOrNull {
                it.roleCode.equals(role.code, ignoreCase = true)
            }?.nameBn ?: role.titleBn
            repository.verifyCashboxAsWitness(record, "$actorName (${role.titleBn})")
        }
    }

    fun markCashboxBankDeposited(record: CashboxRecordEntity, bankName: String, slipNo: String) {
        viewModelScope.launch {
            repository.markCashboxBankDeposited(
                record = record,
                bankName = bankName,
                slipNo = slipNo,
                actor = _currentUserRole.value.titleBn
            )
        }
    }

    fun recordJummahCashboxCount(
        countedAmount: Double,
        denominationBreakdown: String,
        witness1: String,
        witness2: String,
        witness3: String,
        notes: String,
        autoAddIncome: Boolean = true
    ) {
        viewModelScope.launch {
            val role = _currentUserRole.value
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val witnesses = listOf(witness1, witness2, witness3).filter { it.isNotBlank() }.joinToString(", ")
            val fullNotes = buildString {
                appendLine("নোট বিভাজন:")
                appendLine(denominationBreakdown)
                if (notes.isNotBlank()) {
                    appendLine("মন্তব্য: $notes")
                }
            }.trim()

            val record = CashboxRecordEntity(
                id = "cb-jummah-${UUID.randomUUID().toString().take(8)}",
                collectionDate = dateStr,
                boxType = "সাপ্তাহিক জুমার দান বাক্স",
                countedAmount = countedAmount,
                countedBy = role.titleBn,
                witnessNames = witnesses.ifBlank { "ইমাম, কোষাধ্যক্ষ ও নিরপেক্ষ সাক্ষী" },
                witnessVerified = true,
                verifiedBy = witnesses,
                depositStatus = "counted",
                notes = fullNotes
            )
            repository.recordCashboxOpening(record, role.titleBn)

            if (autoAddIncome) {
                addTransaction(
                    categoryNameBn = "জুমার দানবাক্স",
                    type = "INCOME",
                    amount = countedAmount,
                    description = "পবিত্র জুমার দান বাক্স গণনা। ৩ জন সাক্ষীর উপস্থিতিতে গণনাকৃত: $witnesses",
                    sourceType = "jummah_cashbox"
                )
            }
        }
    }

    fun broadcastJanazaAlert(
        deceasedName: String,
        relativeRelation: String,
        guardianName: String,
        age: String,
        villageArea: String,
        timeOfDeath: String,
        janazaVenue: String,
        janazaTime: String,
        graveyardVenue: String,
        contactPhone: String,
        extraNotes: String
    ) {
        val title = "জরুরি জানাজার নোটিশ: মরহুম $deceasedName-এর ইন্তেকাল"
        val content = buildString {
            appendLine("إِنَّا لِلَّهِ وَإِنَّا إِلَيْهِ رَاجِعُونَ")
            appendLine("(নিশ্চয়ই আমরা আল্লাহর এবং আমরা তাঁরই দিকে প্রত্যাবর্তনকারী)")
            appendLine()
            appendLine("অত্যন্ত ভারাক্রান্ত হৃদয়ে জানানো যাচ্ছে যে, আমাদের এলাকার শ্রদ্ধেয় $deceasedName ($relativeRelation: $guardianName, বয়স: ${toBengaliDigits(age)} বছর, গ্রাম/মহল্লা: $villageArea) আজ $timeOfDeath ইন্তেকাল করেছেন।")
            appendLine()
            appendLine("🕌 নামাজে জানাজা:")
            appendLine("• স্থান: $janazaVenue")
            appendLine("• সময়: $janazaTime")
            if (graveyardVenue.isNotBlank()) {
                appendLine("• দাফন: $graveyardVenue")
            }
            if (contactPhone.isNotBlank()) {
                appendLine()
                appendLine("📞 প্রয়োজনে যোগাযোগ: $contactPhone")
            }
            if (extraNotes.isNotBlank()) {
                appendLine()
                appendLine("বিশেষ দ্রষ্টব্য: $extraNotes")
            }
            appendLine()
            appendLine("সকল ধর্মপ্রাণ মুসল্লি ভাইদের মরহুমের জানাজায় শরিক হয়ে মাগফিরাত কামনায় দোয়ার উদাত্ত আহ্বান জানানো যাচ্ছে।")
        }.trim()

        publishNotice(
            title = title,
            content = content,
            priority = "URGENT",
            isPinned = true,
            imageUrl = null
        )
    }

    // --- দপ্তর, দলিল-চুক্তি ও চিঠিপত্র ---
    val allOfficeDocuments: StateFlow<List<OfficeDocumentEntity>> = repository.allOfficeDocuments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addOfficeDocument(
        title: String,
        category: String,
        counterparty: String,
        summary: String,
        status: String
    ) {
        viewModelScope.launch {
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val num = allOfficeDocuments.value.size + 1
            val doc = OfficeDocumentEntity(
                id = "doc-${UUID.randomUUID().toString().take(8)}",
                docCode = "DOC-${String.format(Locale.US, "%03d", num)}",
                title = title,
                category = category,
                counterparty = counterparty,
                docDate = dateStr,
                summary = summary,
                status = status,
                recordedBy = _currentUserRole.value.titleBn
            )
            repository.addOfficeDocument(doc, _currentUserRole.value.titleBn)
        }
    }

    fun updateOfficeDocumentReply(doc: OfficeDocumentEntity, replyNote: String, newStatus: String) {
        viewModelScope.launch {
            repository.updateOfficeDocumentReply(doc, replyNote, newStatus, _currentUserRole.value.titleBn)
        }
    }

    // --- শরিয়াহ পর্যালোচনা ও উপদেষ্টা পরামর্শ ---
    val allAdvisoryNotes: StateFlow<List<AdvisoryNoteEntity>> = repository.allAdvisoryNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun submitAdvisoryNote(
        noteType: String,
        topic: String,
        recommendation: String,
        shariaCompliance: String
    ) {
        viewModelScope.launch {
            val role = _currentUserRole.value
            val authorName = allMembers.value.firstOrNull {
                it.roleCode.equals(role.code, ignoreCase = true)
            }?.nameBn ?: role.titleBn
            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            val note = AdvisoryNoteEntity(
                id = "adv-${UUID.randomUUID().toString().take(8)}",
                noteType = noteType,
                topic = topic,
                recommendation = recommendation,
                authorName = authorName,
                authorRoleTitle = role.titleBn,
                shariaCompliance = shariaCompliance,
                status = "পর্যালোচনাধীন",
                createdDate = dateStr
            )
            repository.submitAdvisoryNote(note)
        }
    }

    fun updateAdvisoryNoteStatus(note: AdvisoryNoteEntity, newStatus: String) {
        viewModelScope.launch {
            repository.updateAdvisoryNoteStatus(note, newStatus, _currentUserRole.value.titleBn)
        }
    }

    // --- প্রচার ও প্রকাশনা / স্মার্ট বোর্ড উক্তি ---
    val allSmartBoardQuotes: StateFlow<List<SmartBoardQuoteEntity>> = repository.allSmartBoardQuotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addSmartBoardQuote(category: String, title: String, message: String, isPinned: Boolean) {
        viewModelScope.launch {
            val quote = SmartBoardQuoteEntity(
                id = "sbq-${UUID.randomUUID().toString().take(8)}",
                category = category,
                title = title,
                message = message,
                isPinned = isPinned,
                createdBy = _currentUserRole.value.titleBn
            )
            repository.addSmartBoardQuote(quote)
        }
    }

    fun togglePinSmartBoardQuote(quote: SmartBoardQuoteEntity) {
        viewModelScope.launch {
            repository.togglePinSmartBoardQuote(quote, _currentUserRole.value.titleBn)
        }
    }

    fun deleteSmartBoardQuote(quote: SmartBoardQuoteEntity) {
        viewModelScope.launch {
            repository.deleteSmartBoardQuote(quote, _currentUserRole.value.titleBn)
        }
    }

    // --- মসজিদ পরিচালনা কমিটি নির্বাচন ও পুনর্গঠন ---
    val allElections: StateFlow<List<ElectionScheduleEntity>> = repository.allElections
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeElection: StateFlow<ElectionScheduleEntity?> = repository.activeElection
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allCandidates: StateFlow<List<ElectionCandidateEntity>> = repository.allCandidates
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun createElection(
        termTitle: String,
        termStartYear: Int,
        termEndYear: Int,
        chiefElectionCommissioner: String,
        commissionerMobile: String,
        scheduleDate: String,
        nominationDeadline: String,
        votingDate: String,
        electionType: String,
        gazetteNotes: String
    ) {
        viewModelScope.launch {
            val election = ElectionScheduleEntity(
                id = "elec-${UUID.randomUUID().toString().take(8)}",
                termTitle = termTitle,
                termStartYear = termStartYear,
                termEndYear = termEndYear,
                chiefElectionCommissioner = chiefElectionCommissioner,
                commissionerMobile = commissionerMobile,
                scheduleDate = scheduleDate,
                nominationDeadline = nominationDeadline,
                votingDate = votingDate,
                status = "nomination_open",
                electionType = electionType,
                gazetteNotes = gazetteNotes
            )
            repository.createElection(election, _currentUserRole.value.titleBn)
            if (sessionManager.isNotificationsEnabled()) {
                MosquePushNotificationHelper.postElectionNotification(getApplication(), election, "তফসিল ঘোষণা")
            }
        }
    }

    fun updateElectionStatus(election: ElectionScheduleEntity, newStatus: String) {
        viewModelScope.launch {
            val updated = election.copy(status = newStatus)
            repository.updateElection(updated, _currentUserRole.value.titleBn)
            if (sessionManager.isNotificationsEnabled()) {
                val milestone = when (newStatus) {
                    "voting_ongoing" -> "ভোটগ্রহণ শুরু"
                    "results_published" -> "ফলাফল ও গেজেট প্রকাশ"
                    "completed" -> "নতুন কমিটি শপথ ও দায়িত্ব গ্রহণ"
                    else -> "পর্যায় আপডেট"
                }
                MosquePushNotificationHelper.postElectionNotification(getApplication(), updated, milestone)
            }
        }
    }

    fun sendTestPushNotification() {
        MosquePushNotificationHelper.postTestNotification(getApplication())
    }

    fun addElectionCandidate(
        electionId: String,
        targetRoleCode: String,
        targetRoleTitleBn: String,
        candidateNameBn: String,
        candidateMobile: String,
        memberCode: String,
        proposerNameBn: String,
        seconderNameBn: String,
        symbolOrPanel: String
    ) {
        viewModelScope.launch {
            val candidate = ElectionCandidateEntity(
                id = "cand-${UUID.randomUUID().toString().take(8)}",
                electionId = electionId,
                targetRoleCode = targetRoleCode,
                targetRoleTitleBn = targetRoleTitleBn,
                candidateNameBn = candidateNameBn,
                candidateMobile = candidateMobile,
                memberCode = memberCode,
                proposerNameBn = proposerNameBn,
                seconderNameBn = seconderNameBn,
                status = "valid",
                symbolOrPanel = symbolOrPanel.ifBlank { "ঐক্য প্যানেল" }
            )
            repository.addCandidate(candidate, _currentUserRole.value.titleBn)
        }
    }

    fun markCandidateElected(candidate: ElectionCandidateEntity, isElected: Boolean, votes: Int = 0) {
        viewModelScope.launch {
            repository.updateCandidate(
                candidate.copy(
                    isElected = isElected,
                    status = if (isElected) "elected" else "valid",
                    votesReceived = votes
                ),
                _currentUserRole.value.titleBn
            )
        }
    }

    fun deleteCandidate(candidate: ElectionCandidateEntity) {
        viewModelScope.launch {
            repository.deleteCandidate(candidate, _currentUserRole.value.titleBn)
        }
    }

    fun activateNewCommittee(election: ElectionScheduleEntity) {
        viewModelScope.launch {
            repository.activateNewCommittee(election, _currentUserRole.value.titleBn)
            val m = mosque.value
            if (m != null) {
                repository.updateMosque(
                    m.copy(
                        committeeStartYear = election.termStartYear,
                        committeeEndYear = election.termEndYear
                    )
                )
            }
        }
    }

    // --- মসজিদের স্থাবর ও অস্থাবর সম্পত্তি (Mosque Properties & Assets) ---
    val mosqueProperties: StateFlow<List<MosquePropertyEntity>> = repository.allProperties
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun saveMosqueProperty(property: MosquePropertyEntity) {
        viewModelScope.launch {
            val propId = if (property.id.isBlank()) "PROP-${UUID.randomUUID().toString().take(8).uppercase()}" else property.id
            val existing = mosqueProperties.value.find { it.id == propId }
            if (existing != null) {
                repository.updateProperty(property.copy(id = propId), _currentUserRole.value.titleBn)
            } else {
                repository.addProperty(property.copy(id = propId), _currentUserRole.value.titleBn)
            }
        }
    }

    fun deleteMosqueProperty(property: MosquePropertyEntity) {
        viewModelScope.launch {
            repository.deleteProperty(property, _currentUserRole.value.titleBn)
        }
    }
}
